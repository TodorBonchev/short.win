/**
 * Program IDL in camelCase format in order to be used in JS/TS.
 *
 * Note that this is only a type helper and is not the actual IDL. The original
 * IDL can be found at `target/idl/shortwin.json`.
 */
export type Shortwin = {
  "address": "5yvyAddWb8RRGh3pPiFS5eV33eZYeHVmAAfwAFmqVpKK",
  "metadata": {
    "name": "shortwin",
    "version": "1.0.3",
    "spec": "0.1.0",
    "description": "short.win: permissionless P2P token lending for shorting memecoins (Anchor program)",
    "repository": "https://github.com/TodorBonchev/short.win"
  },
  "instructions": [
    {
      "name": "addMargin",
      "docs": [
        "The borrower adds SOL margin to its position (it only raises CR)."
      ],
      "discriminator": [
        211,
        238,
        238,
        90,
        223,
        228,
        228,
        76
      ],
      "accounts": [
        {
          "name": "borrower",
          "writable": true,
          "signer": true,
          "relations": [
            "position"
          ]
        },
        {
          "name": "market",
          "docs": [
            "Read only (C0-17); bound to its PDA with the stored bump."
          ],
          "relations": [
            "position"
          ]
        },
        {
          "name": "position",
          "writable": true
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "amount",
          "type": "u64"
        }
      ]
    },
    {
      "name": "applyConfig",
      "docs": [
        "Anyone applies the pending change once its timelock has run."
      ],
      "discriminator": [
        121,
        42,
        53,
        8,
        51,
        150,
        105,
        249
      ],
      "accounts": [
        {
          "name": "config",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "feeRecipient",
          "docs": [
            "`check_fee_recipient` (System-owned, not executable); `mut` proves the runtime lets it",
            "be written. Never read or written otherwise."
          ],
          "writable": true,
          "optional": true
        },
        {
          "name": "oracleCache",
          "docs": [
            "`OracleFeed` only: emptied (the bump stays)."
          ],
          "writable": true,
          "optional": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  115,
                  111,
                  108,
                  95,
                  117,
                  115,
                  100
                ]
              }
            ]
          }
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "cancelConfig",
      "docs": [
        "Governance or the Emergency vault cancels the pending change."
      ],
      "discriminator": [
        91,
        124,
        207,
        75,
        179,
        108,
        227,
        13
      ],
      "accounts": [
        {
          "name": "authority",
          "docs": [
            "`governance` or `pause_authority`."
          ],
          "signer": true
        },
        {
          "name": "config",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "claimSol",
      "docs": [
        "A lender claims its realised SOL."
      ],
      "discriminator": [
        139,
        113,
        179,
        189,
        190,
        30,
        132,
        195
      ],
      "accounts": [
        {
          "name": "owner",
          "docs": [
            "The lender; receives the SOL, and the `LenderPosition` rent when the claim closes it",
            "(KI-67)."
          ],
          "writable": true,
          "signer": true,
          "relations": [
            "lender"
          ]
        },
        {
          "name": "market",
          "docs": [
            "Read-only (C0-17). Bound to its PDA `[\"market\", mint]` with the stored bump",
            "(`Market::is_pda`; ARCH §2.3; M1-SEC-6 / M1-FID-6)."
          ],
          "relations": [
            "lender"
          ]
        },
        {
          "name": "lender",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  110,
                  100,
                  101,
                  114
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "owner"
              }
            ]
          }
        },
        {
          "name": "marketVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "closeShort",
      "docs": [
        "The borrower buys back and closes its position."
      ],
      "discriminator": [
        159,
        16,
        29,
        141,
        209,
        68,
        25,
        0
      ],
      "accounts": [
        {
          "name": "borrower",
          "docs": [
            "The position's borrower; receives the position's remainder and rent (A18)."
          ],
          "writable": true,
          "signer": true,
          "relations": [
            "position"
          ]
        },
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "mint"
              }
            ]
          },
          "relations": [
            "position",
            "exposure"
          ]
        },
        {
          "name": "position",
          "docs": [
            "Bound to its PDA `[\"position\", market, borrower, nonce]` with the stored bump."
          ],
          "writable": true
        },
        {
          "name": "exposure",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  101,
                  120,
                  112,
                  111,
                  115,
                  117,
                  114,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrower"
              }
            ]
          }
        },
        {
          "name": "mint",
          "relations": [
            "market"
          ]
        },
        {
          "name": "poolVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  111,
                  111,
                  108,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "marketVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "trader",
          "writable": true,
          "relations": [
            "market"
          ]
        },
        {
          "name": "tokenProgram",
          "relations": [
            "market"
          ]
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "maxBuybackCost",
          "type": "u64"
        },
        {
          "name": "extras",
          "type": {
            "defined": {
              "name": "extrasSel"
            }
          }
        }
      ]
    },
    {
      "name": "coverDeficit",
      "docs": [
        "A lender covers a negative SOL balance."
      ],
      "discriminator": [
        111,
        47,
        68,
        186,
        165,
        82,
        169,
        88
      ],
      "accounts": [
        {
          "name": "owner",
          "docs": [
            "The lender; pays the lamports."
          ],
          "writable": true,
          "signer": true,
          "relations": [
            "lender"
          ]
        },
        {
          "name": "market",
          "docs": [
            "Read-only (C0-17). Bound to its PDA `[\"market\", mint]` with the stored bump",
            "(`Market::is_pda`; ARCH §2.3; M1-SEC-6 / M1-FID-6)."
          ],
          "relations": [
            "lender"
          ]
        },
        {
          "name": "lender",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  110,
                  100,
                  101,
                  114
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "owner"
              }
            ]
          }
        },
        {
          "name": "marketVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "lamports",
          "type": "u64"
        }
      ]
    },
    {
      "name": "crankPrice",
      "docs": [
        "Anyone runs a market's prologue (observation, chains) and refreshes its tier."
      ],
      "discriminator": [
        8,
        89,
        67,
        221,
        50,
        129,
        35,
        48
      ],
      "accounts": [
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "mint"
              }
            ]
          }
        },
        {
          "name": "mint",
          "docs": [
            "in the handler); PumpSwap's fee tier reads its supply (M6)."
          ],
          "relations": [
            "market"
          ]
        },
        {
          "name": "oracleCache",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  115,
                  111,
                  108,
                  95,
                  117,
                  115,
                  100
                ]
              }
            ]
          }
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "crankSolUsd",
      "docs": [
        "Anyone refreshes the cached SOL/USD price."
      ],
      "discriminator": [
        30,
        70,
        37,
        154,
        143,
        244,
        144,
        113
      ],
      "accounts": [
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "oracleCache",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  115,
                  111,
                  108,
                  95,
                  117,
                  115,
                  100
                ]
              }
            ]
          }
        },
        {
          "name": "priceUpdate",
          "docs": [
            "The configured Pyth `PriceUpdateV2` (address `config.pyth_sol_usd`, owner the receiver)."
          ]
        }
      ],
      "args": []
    },
    {
      "name": "createMarket",
      "docs": [
        "Anyone lists a mint, paying at most `max_creation_fee`."
      ],
      "discriminator": [
        103,
        226,
        97,
        235,
        200,
        188,
        251,
        254
      ],
      "accounts": [
        {
          "name": "creator",
          "docs": [
            "Pays for every account and the creation fee. Confers nothing: `Market.creator` is",
            "informational."
          ],
          "writable": true,
          "signer": true
        },
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "venueGuard",
          "docs": [
            "The venue-upgrade latch (A7; M3-SEC-2): a Raydium listing is refused while a bit of the",
            "Raydium mask is set (`VenueUpgraded`), as opens are. Read only."
          ],
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  118,
                  101,
                  110,
                  117,
                  101,
                  95,
                  103,
                  117,
                  97,
                  114,
                  100
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "docs": [
            "One market per mint, whatever its token program."
          ],
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "mint"
              }
            ]
          }
        },
        {
          "name": "marketVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          }
        },
        {
          "name": "poolVault",
          "docs": [
            "The PDA-addressed pool vault: a token account of `mint` owned by `token_program`,",
            "authority = the market PDA. Not an ATA: a pre-created ATA would block the listing",
            "forever (R-MINT §8.2)."
          ],
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  111,
                  111,
                  108,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          }
        },
        {
          "name": "mint",
          "docs": [
            "The listed mint: owned by SPL Token or Token-2022 (and by `token_program`), not a",
            "native mint, well-formed, no freeze authority, allowlisted extensions only."
          ]
        },
        {
          "name": "trader",
          "docs": [
            "The market's `trader` PDA (`[\"trader\", market]`): system-owned, zero data, never",
            "allocated (ARCH §2.4)."
          ],
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  116,
                  114,
                  97,
                  100,
                  101,
                  114
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          }
        },
        {
          "name": "traderBaseAta",
          "docs": [
            "`ATA(trader, mint, token_program)`: created with `create_idempotent` and then",
            "validated on the pump venues (M5)."
          ],
          "writable": true
        },
        {
          "name": "tokenProgram"
        },
        {
          "name": "associatedTokenProgram",
          "address": "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "venueHint",
          "type": "u8"
        },
        {
          "name": "maxCreationFee",
          "type": "u64"
        }
      ]
    },
    {
      "name": "deposit",
      "docs": [
        "A lender deposits tokens."
      ],
      "discriminator": [
        242,
        35,
        198,
        137,
        82,
        225,
        242,
        182
      ],
      "accounts": [
        {
          "name": "owner",
          "docs": [
            "The lender; pays for its `LenderPosition` on first deposit."
          ],
          "writable": true,
          "signer": true
        },
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "mint"
              }
            ]
          }
        },
        {
          "name": "marketVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "lender",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  110,
                  100,
                  101,
                  114
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "owner"
              }
            ]
          }
        },
        {
          "name": "mint",
          "relations": [
            "market"
          ]
        },
        {
          "name": "ownerTokenAccount",
          "docs": [
            "The lender's source token account (its authority is checked by the token program)."
          ],
          "writable": true
        },
        {
          "name": "poolVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  111,
                  111,
                  108,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "tokenProgram",
          "relations": [
            "market"
          ]
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "amount",
          "type": "u64"
        },
        {
          "name": "minShares",
          "type": "u128"
        }
      ]
    },
    {
      "name": "disableVenue",
      "docs": [
        "The Emergency vault disables a venue for opens."
      ],
      "discriminator": [
        228,
        150,
        61,
        116,
        123,
        69,
        29,
        54
      ],
      "accounts": [
        {
          "name": "pauseAuthority",
          "signer": true
        },
        {
          "name": "config",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "bit",
          "type": "u8"
        }
      ]
    },
    {
      "name": "executePoolSwitch",
      "docs": [
        "Anyone resolves a collection window once it has run: adopts the best candidate if it is",
        "still eligible (with its locked SOL at the SOL floor), its program is not latched and,",
        "on a Raydium market, the `pool_fail` chain that armed the window still holds; else",
        "cancels."
      ],
      "discriminator": [
        255,
        50,
        233,
        181,
        206,
        56,
        90,
        172
      ],
      "accounts": [
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "venueGuard",
          "docs": [
            "The venue-upgrade latch: a window whose candidate's program bit is set is cancelled, not",
            "adopted (module docs step 5; M4-SEC-8, M4V-4). Read only."
          ],
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  118,
                  101,
                  110,
                  117,
                  101,
                  95,
                  103,
                  117,
                  97,
                  114,
                  100
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "mint"
              }
            ]
          }
        },
        {
          "name": "mint",
          "docs": [
            "the handler)."
          ],
          "relations": [
            "market"
          ]
        },
        {
          "name": "oracleCache",
          "docs": [
            "The cached SOL/USD price: the tier the market would have on the window's candidate, whose",
            "opening caps its open positions must fit (\"switch only if all fit\"; module docs step 4).",
            "Read only."
          ],
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  115,
                  111,
                  108,
                  95,
                  117,
                  115,
                  100
                ]
              }
            ]
          }
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "expire",
      "docs": [
        "A keeper exits an expired, not CR-liquidatable position (ARCH §3.7)."
      ],
      "discriminator": [
        243,
        83,
        205,
        58,
        57,
        201,
        247,
        146
      ],
      "accounts": [
        {
          "name": "keeper",
          "docs": [
            "The keeper (anyone)."
          ],
          "writable": true,
          "signer": true
        },
        {
          "name": "borrower",
          "writable": true,
          "relations": [
            "position"
          ]
        },
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "mint"
              }
            ]
          },
          "relations": [
            "position",
            "exposure"
          ]
        },
        {
          "name": "position",
          "writable": true
        },
        {
          "name": "exposure",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  101,
                  120,
                  112,
                  111,
                  115,
                  117,
                  114,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrower"
              }
            ]
          }
        },
        {
          "name": "mint",
          "relations": [
            "market"
          ]
        },
        {
          "name": "poolVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  111,
                  111,
                  108,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "marketVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "trader",
          "writable": true,
          "relations": [
            "market"
          ]
        },
        {
          "name": "tokenProgram",
          "relations": [
            "market"
          ]
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "extras",
          "type": {
            "defined": {
              "name": "extrasSel"
            }
          }
        }
      ]
    },
    {
      "name": "flagUnsafeMint",
      "docs": [
        "Anyone flags a market whose mint fails the safety filter."
      ],
      "discriminator": [
        65,
        65,
        54,
        154,
        190,
        218,
        0,
        169
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "mint"
              }
            ]
          }
        },
        {
          "name": "mint",
          "docs": [
            "The market's mint, parsed by the filter."
          ],
          "relations": [
            "market"
          ]
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "flagVenueUpgraded",
      "docs": [
        "Anyone records a venue program upgrade in the latch."
      ],
      "discriminator": [
        184,
        50,
        205,
        73,
        15,
        183,
        159,
        5
      ],
      "accounts": [
        {
          "name": "venueGuard",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  118,
                  101,
                  110,
                  117,
                  101,
                  95,
                  103,
                  117,
                  97,
                  114,
                  100
                ]
              }
            ]
          }
        },
        {
          "name": "programData",
          "docs": [
            "upgradeable loader; its header is read (`shortwin_venue_state`), and its ELF when the",
            "account grew since a fingerprinted revalidation (AIR-01)."
          ]
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "venue",
          "type": "u8"
        }
      ]
    },
    {
      "name": "initializeConfig",
      "docs": [
        "Creates `GlobalConfig`, `VenueGuard`, the `VenueExtras` and `OracleCache` (upgrade",
        "authority, once)."
      ],
      "discriminator": [
        208,
        127,
        21,
        1,
        194,
        190,
        196,
        70
      ],
      "accounts": [
        {
          "name": "authority",
          "docs": [
            "short.win's upgrade authority (checked against `program_data`); pays for the accounts."
          ],
          "writable": true,
          "signer": true
        },
        {
          "name": "config",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "venueGuard",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  118,
                  101,
                  110,
                  117,
                  101,
                  95,
                  103,
                  117,
                  97,
                  114,
                  100
                ]
              }
            ]
          }
        },
        {
          "name": "venueExtrasPumpCurve",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  118,
                  101,
                  110,
                  117,
                  101,
                  95,
                  101,
                  120,
                  116,
                  114,
                  97,
                  115
                ]
              },
              {
                "kind": "const",
                "value": [
                  1
                ]
              }
            ]
          }
        },
        {
          "name": "venueExtrasPumpSwap",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  118,
                  101,
                  110,
                  117,
                  101,
                  95,
                  101,
                  120,
                  116,
                  114,
                  97,
                  115
                ]
              },
              {
                "kind": "const",
                "value": [
                  3
                ]
              }
            ]
          }
        },
        {
          "name": "venueExtrasRaydiumV4",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  118,
                  101,
                  110,
                  117,
                  101,
                  95,
                  101,
                  120,
                  116,
                  114,
                  97,
                  115
                ]
              },
              {
                "kind": "const",
                "value": [
                  4
                ]
              }
            ]
          }
        },
        {
          "name": "venueExtrasRaydiumCpmm",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  118,
                  101,
                  110,
                  117,
                  101,
                  95,
                  101,
                  120,
                  116,
                  114,
                  97,
                  115
                ]
              },
              {
                "kind": "const",
                "value": [
                  5
                ]
              }
            ]
          }
        },
        {
          "name": "oracleCache",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  115,
                  111,
                  108,
                  95,
                  117,
                  115,
                  100
                ]
              }
            ]
          }
        },
        {
          "name": "programData",
          "docs": [
            "short.win's own ProgramData (`PDA(BPFLoaderUpgradeable, [program id])`); its upgrade",
            "authority must be the signer."
          ],
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  74,
                  4,
                  75,
                  149,
                  226,
                  217,
                  183,
                  94,
                  211,
                  73,
                  108,
                  137,
                  193,
                  39,
                  32,
                  165,
                  239,
                  249,
                  233,
                  248,
                  176,
                  235,
                  222,
                  98,
                  115,
                  38,
                  206,
                  223,
                  11,
                  144,
                  136,
                  162
                ]
              }
            ],
            "program": {
              "kind": "const",
              "value": [
                2,
                168,
                246,
                145,
                78,
                136,
                161,
                176,
                226,
                16,
                21,
                62,
                247,
                99,
                174,
                43,
                0,
                194,
                185,
                61,
                22,
                193,
                36,
                210,
                192,
                83,
                122,
                16,
                4,
                128,
                0,
                0
              ]
            }
          }
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "initConfigArgs"
            }
          }
        }
      ]
    },
    {
      "name": "initializePriceReport",
      "docs": [
        "Governance creates immutable exact-q report persistence; this admits no financial action."
      ],
      "discriminator": [
        107,
        190,
        18,
        196,
        64,
        24,
        193,
        47
      ],
      "accounts": [
        {
          "name": "authority",
          "writable": true,
          "signer": true
        },
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "market"
        },
        {
          "name": "priceReport",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  114,
                  105,
                  99,
                  101,
                  95,
                  114,
                  101,
                  112,
                  111,
                  114,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "arg",
                "path": "args.quantity"
              },
              {
                "kind": "arg",
                "path": "args.model.epoch"
              }
            ]
          }
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "initializePriceReportArgs"
            }
          }
        }
      ]
    },
    {
      "name": "liquidate",
      "docs": [
        "A keeper liquidates a CR-liquidatable position within the fixed exit bound (ARCH §3.6)."
      ],
      "discriminator": [
        223,
        179,
        226,
        125,
        48,
        46,
        39,
        74
      ],
      "accounts": [
        {
          "name": "keeper",
          "docs": [
            "The keeper (anyone)."
          ],
          "writable": true,
          "signer": true
        },
        {
          "name": "borrower",
          "writable": true,
          "relations": [
            "position"
          ]
        },
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "mint"
              }
            ]
          },
          "relations": [
            "position",
            "exposure"
          ]
        },
        {
          "name": "position",
          "writable": true
        },
        {
          "name": "exposure",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  101,
                  120,
                  112,
                  111,
                  115,
                  117,
                  114,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrower"
              }
            ]
          }
        },
        {
          "name": "mint",
          "relations": [
            "market"
          ]
        },
        {
          "name": "poolVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  111,
                  111,
                  108,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "marketVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "trader",
          "writable": true,
          "relations": [
            "market"
          ]
        },
        {
          "name": "tokenProgram",
          "relations": [
            "market"
          ]
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "extras",
          "type": {
            "defined": {
              "name": "extrasSel"
            }
          }
        }
      ]
    },
    {
      "name": "openShort",
      "docs": [
        "A borrower opens a short of `q` tokens (borrow, sell, lock proceeds and D4 margin)."
      ],
      "discriminator": [
        66,
        191,
        209,
        162,
        3,
        36,
        159,
        99
      ],
      "accounts": [
        {
          "name": "borrower",
          "docs": [
            "The borrower: pays for the position, the exposure record, the margin and the open fee."
          ],
          "writable": true,
          "signer": true
        },
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "venueGuard",
          "docs": [
            "The venue-upgrade latch (A7): read only by opens."
          ],
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  118,
                  101,
                  110,
                  117,
                  101,
                  95,
                  103,
                  117,
                  97,
                  114,
                  100
                ]
              }
            ]
          }
        },
        {
          "name": "oracleCache",
          "docs": [
            "The cached SOL/USD price for the tier (ARCH §4.7)."
          ],
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  115,
                  111,
                  108,
                  95,
                  117,
                  115,
                  100
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "mint"
              }
            ]
          }
        },
        {
          "name": "position",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrower"
              },
              {
                "kind": "arg",
                "path": "nonce"
              }
            ]
          }
        },
        {
          "name": "exposure",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  101,
                  120,
                  112,
                  111,
                  115,
                  117,
                  114,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrower"
              }
            ]
          }
        },
        {
          "name": "mint",
          "relations": [
            "market"
          ]
        },
        {
          "name": "poolVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  111,
                  111,
                  108,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "marketVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "trader",
          "docs": [
            "normalisation."
          ],
          "writable": true,
          "relations": [
            "market"
          ]
        },
        {
          "name": "tokenProgram",
          "relations": [
            "market"
          ]
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "nonce",
          "type": "u64"
        },
        {
          "name": "q",
          "type": "u64"
        },
        {
          "name": "minProceeds",
          "type": "u64"
        },
        {
          "name": "maxMargin",
          "type": "u64"
        },
        {
          "name": "maxOpenFee",
          "type": "u64"
        },
        {
          "name": "extras",
          "type": {
            "defined": {
              "name": "extrasSel"
            }
          }
        }
      ]
    },
    {
      "name": "proposeConfig",
      "docs": [
        "Governance proposes a timelocked config change."
      ],
      "discriminator": [
        163,
        247,
        238,
        160,
        236,
        129,
        153,
        160
      ],
      "accounts": [
        {
          "name": "governance",
          "signer": true
        },
        {
          "name": "config",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "change",
          "type": {
            "defined": {
              "name": "configChange"
            }
          }
        }
      ]
    },
    {
      "name": "proposePool",
      "docs": [
        "Anyone proposes a Raydium pool of kind `candidate_kind` (4 AMM v4, 5 CPMM) for a",
        "list-only or Raydium market: an immediate adoption (a list-only market without open",
        "positions; no open position with the listing-window or zero-position margin) or a",
        "collection window (the fast path; a list-only market with open positions)."
      ],
      "discriminator": [
        13,
        47,
        166,
        121,
        182,
        244,
        168,
        236
      ],
      "accounts": [
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "venueGuard",
          "docs": [
            "The venue-upgrade latch (A7; module docs step 3): a proposal is refused while the bit of",
            "the candidate's program is set (`VenueUpgraded`, M4-SEC-8). Read only."
          ],
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  118,
                  101,
                  110,
                  117,
                  101,
                  95,
                  103,
                  117,
                  97,
                  114,
                  100
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "mint"
              }
            ]
          }
        },
        {
          "name": "mint",
          "docs": [
            "the handler); the candidate's token side must be this mint under that program."
          ],
          "relations": [
            "market"
          ]
        },
        {
          "name": "oracleCache",
          "docs": [
            "The cached SOL/USD price: the tier the market would have on a window candidate, whose",
            "opening caps its open positions must fit (\"switch only if all fit\"; module docs step 6).",
            "Read only."
          ],
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  115,
                  111,
                  108,
                  95,
                  117,
                  115,
                  100
                ]
              }
            ]
          }
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "candidateKind",
          "type": "u8"
        }
      ]
    },
    {
      "name": "publishPriceReport",
      "docs": [
        "An authorized runtime signer publishes finite/Unknown evidence without financial authority."
      ],
      "discriminator": [
        83,
        130,
        3,
        116,
        85,
        225,
        131,
        88
      ],
      "accounts": [
        {
          "name": "publisher",
          "signer": true
        },
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "market"
        },
        {
          "name": "priceReport",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  114,
                  105,
                  99,
                  101,
                  95,
                  114,
                  101,
                  112,
                  111,
                  114,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "priceReport.quantity",
                "account": "priceReport"
              },
              {
                "kind": "account",
                "path": "priceReport.modelEpoch",
                "account": "priceReport"
              }
            ]
          }
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "publishPriceReportArgs"
            }
          }
        }
      ]
    },
    {
      "name": "repayShort",
      "docs": [
        "Borrower returns all owed tokens in-kind, paying accrued rent within max_rent.",
        "No swap route, oracle or price history is required."
      ],
      "discriminator": [
        222,
        215,
        167,
        6,
        20,
        137,
        188,
        39
      ],
      "accounts": [
        {
          "name": "borrower",
          "writable": true,
          "signer": true,
          "relations": [
            "position"
          ]
        },
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "mint"
              }
            ]
          },
          "relations": [
            "position",
            "exposure"
          ]
        },
        {
          "name": "position",
          "writable": true
        },
        {
          "name": "exposure",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  101,
                  120,
                  112,
                  111,
                  115,
                  117,
                  114,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrower"
              }
            ]
          }
        },
        {
          "name": "mint",
          "relations": [
            "market"
          ]
        },
        {
          "name": "borrowerTokenAccount",
          "writable": true
        },
        {
          "name": "poolVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  111,
                  111,
                  108,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "marketVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "tokenProgram",
          "relations": [
            "market"
          ]
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "maxRent",
          "type": "u64"
        }
      ]
    },
    {
      "name": "revalidateVenue",
      "docs": [
        "The Emergency vault re-validates an upgraded venue program at `expected_slot`, naming",
        "the sha256 of the trimmed ELF it reviewed (AIR-01; all zero: the slot alone)."
      ],
      "discriminator": [
        172,
        143,
        90,
        194,
        85,
        102,
        243,
        3
      ],
      "accounts": [
        {
          "name": "pauseAuthority",
          "signer": true
        },
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "venueGuard",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  118,
                  101,
                  110,
                  117,
                  101,
                  95,
                  103,
                  117,
                  97,
                  114,
                  100
                ]
              }
            ]
          }
        },
        {
          "name": "programData",
          "docs": [
            "upgradeable loader; its header is read, and its ELF when the slot moved (AIR-01)."
          ]
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "venue",
          "type": "u8"
        },
        {
          "name": "expectedSlot",
          "type": "u64"
        },
        {
          "name": "expectedElfHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          }
        }
      ]
    },
    {
      "name": "setCoveragePause",
      "docs": [
        "The keeper's `coverage_authority` pauses or resumes new opens on one market for lost",
        "keeper coverage (degraded mode; O17); the Emergency vault may resume them too (clear",
        "only; OWNER-M7-3). Opens only; moves nothing."
      ],
      "discriminator": [
        23,
        246,
        170,
        138,
        239,
        63,
        245,
        123
      ],
      "accounts": [
        {
          "name": "coverageAuthority",
          "docs": [
            "`config.coverage_authority` (the keeper's pause-opens-only key; O17: sets or clears), or",
            "`config.pause_authority` (the Emergency vault; OWNER-M7-3 (b): clears only)."
          ],
          "signer": true
        },
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "docs": [
            "The market, bound to its PDA `[\"market\", mint]` with the stored bump (`Market::is_pda`;",
            "M1-SEC-6)."
          ],
          "writable": true
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "paused",
          "type": "bool"
        },
        {
          "name": "reason",
          "type": "u8"
        }
      ]
    },
    {
      "name": "setPause",
      "docs": [
        "Pauses or resumes new opens, globally or on one market."
      ],
      "discriminator": [
        63,
        32,
        154,
        2,
        56,
        103,
        79,
        45
      ],
      "accounts": [
        {
          "name": "authority",
          "docs": [
            "`pause_authority` or `governance`."
          ],
          "signer": true
        },
        {
          "name": "config",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "docs": [
            "The market, for `PauseScope::Market` only; bound to its PDA `[\"market\", mint]` with the",
            "stored bump (`Market::is_pda`; ARCH §2.3; M1-SEC-6)."
          ],
          "writable": true,
          "optional": true
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "scope",
          "type": {
            "defined": {
              "name": "pauseScope"
            }
          }
        },
        {
          "name": "paused",
          "type": "bool"
        }
      ]
    },
    {
      "name": "setRouteBroken",
      "docs": [
        "The Emergency vault flags or clears a broken route (opens and S3 evidence only)."
      ],
      "discriminator": [
        177,
        160,
        0,
        3,
        36,
        20,
        215,
        230
      ],
      "accounts": [
        {
          "name": "authority",
          "docs": [
            "`pause_authority` or `governance`."
          ],
          "signer": true
        },
        {
          "name": "config",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "docs": [
            "The market, for `PauseScope::Market` only; bound to its PDA `[\"market\", mint]` with",
            "the stored bump (`Market::is_pda`)."
          ],
          "writable": true,
          "optional": true
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "scope",
          "type": {
            "defined": {
              "name": "pauseScope"
            }
          }
        },
        {
          "name": "venueBit",
          "type": "u8"
        },
        {
          "name": "broken",
          "type": "bool"
        }
      ]
    },
    {
      "name": "setVenueExtras",
      "docs": [
        "The Emergency vault publishes a venue's bounded trailing accounts."
      ],
      "discriminator": [
        28,
        35,
        237,
        216,
        131,
        255,
        50,
        94
      ],
      "accounts": [
        {
          "name": "authority",
          "docs": [
            "`pause_authority` or `governance`."
          ],
          "signer": true
        },
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "venueExtras",
          "writable": true
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "venue",
          "type": "u8"
        },
        {
          "name": "ix",
          "type": "u8"
        },
        {
          "name": "entries",
          "type": {
            "vec": {
              "defined": {
                "name": "extraEntryArg"
              }
            }
          }
        }
      ]
    },
    {
      "name": "solSettle",
      "docs": [
        "A keeper settles a position in SOL on the settlement box (S1/S2/S3; ARCH §3.8)."
      ],
      "discriminator": [
        155,
        7,
        196,
        156,
        51,
        120,
        51,
        2
      ],
      "accounts": [
        {
          "name": "keeper",
          "docs": [
            "The keeper (anyone); pays for a new `ShareEpoch` record."
          ],
          "writable": true,
          "signer": true
        },
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "mint"
              }
            ]
          },
          "relations": [
            "position",
            "exposure"
          ]
        },
        {
          "name": "position",
          "writable": true
        },
        {
          "name": "borrower",
          "writable": true,
          "relations": [
            "position"
          ]
        },
        {
          "name": "exposure",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  101,
                  120,
                  112,
                  111,
                  115,
                  117,
                  114,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrower"
              }
            ]
          }
        },
        {
          "name": "marketVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "mint",
          "relations": [
            "market"
          ]
        },
        {
          "name": "shareEpochRec",
          "docs": [
            "market.share_epoch])`; created with the grief-proof helper only when the epoch rolls."
          ],
          "writable": true
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "sweepProtocolFees",
      "docs": [
        "Anyone moves a market's protocol fees to the configured recipient."
      ],
      "discriminator": [
        117,
        225,
        240,
        75,
        71,
        195,
        44,
        43
      ],
      "accounts": [
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "docs": [
            "Bound to its PDA `[\"market\", mint]` with the stored bump",
            "(`Market::is_pda`; ARCH §2.3; M1-SEC-6)."
          ]
        },
        {
          "name": "marketVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "feeRecipient",
          "writable": true
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "sweepTrader",
      "docs": [
        "Anyone sweeps SOL left on a market's trader side to lenders; after a full wipe it",
        "credits the wipe record and sets `wipe_trader_swept` (ARCH §3.9; M2-SEC-4)."
      ],
      "discriminator": [
        244,
        159,
        222,
        169,
        87,
        76,
        64,
        94
      ],
      "accounts": [
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "docs": [
            "Bound to its PDA `[\"market\", mint]` with the stored bump (`Market::is_pda`; no mint is",
            "passed)."
          ],
          "writable": true
        },
        {
          "name": "marketVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "trader",
          "docs": [
            "normalisation)."
          ],
          "writable": true,
          "relations": [
            "market"
          ]
        },
        {
          "name": "traderWsol",
          "docs": [
            "instructions (checked by the normalisation)."
          ],
          "writable": true,
          "relations": [
            "market"
          ]
        },
        {
          "name": "traderWsolAta",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "syncLender",
      "docs": [
        "Anyone advances a lender through share epochs; through a rebase record only its owner,",
        "anyone else's sync stopping there with the pot-only touch (KI-66)."
      ],
      "discriminator": [
        189,
        69,
        70,
        152,
        60,
        247,
        18,
        48
      ],
      "accounts": [
        {
          "name": "market",
          "docs": [
            "Read-only (C0-17). Bound to its PDA `[\"market\", mint]` with the stored bump",
            "(`Market::is_pda`; ARCH §2.3; M1-SEC-6 / M1-FID-6)."
          ],
          "relations": [
            "lender"
          ]
        },
        {
          "name": "marketVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "lender",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  110,
                  100,
                  101,
                  114
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "owner"
              }
            ]
          }
        },
        {
          "name": "owner",
          "docs": [
            "The position's owner. Signing, it converts the lender through rebase records",
            "(KI65-REV-SEC1); unsigned, anyone may send the instruction, which then stops at a rebase",
            "record with the pot-only touch (KI-66)."
          ],
          "relations": [
            "lender"
          ]
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "maxEpochs",
          "type": "u8"
        }
      ]
    },
    {
      "name": "withdraw",
      "docs": [
        "A lender withdraws its pro-rata part (tokens and SOL), bounded below by `min_tokens`",
        "and `min_sol`."
      ],
      "discriminator": [
        183,
        18,
        70,
        156,
        148,
        109,
        161,
        34
      ],
      "accounts": [
        {
          "name": "owner",
          "docs": [
            "The lender; receives the SOL part and the `LenderPosition` rent when it closes."
          ],
          "writable": true,
          "signer": true,
          "relations": [
            "lender"
          ]
        },
        {
          "name": "config",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  99,
                  111,
                  110,
                  102,
                  105,
                  103
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "mint"
              }
            ]
          },
          "relations": [
            "lender"
          ]
        },
        {
          "name": "marketVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "lender",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  110,
                  100,
                  101,
                  114
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "owner"
              }
            ]
          }
        },
        {
          "name": "mint",
          "relations": [
            "market"
          ]
        },
        {
          "name": "ownerTokenAccount",
          "docs": [
            "The destination token account (any account of this mint the owner chooses)."
          ],
          "writable": true
        },
        {
          "name": "poolVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  111,
                  111,
                  108,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              }
            ]
          },
          "relations": [
            "market"
          ]
        },
        {
          "name": "tokenProgram",
          "relations": [
            "market"
          ]
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "memoProgram",
          "docs": [
            "memos. spl-memo v3/v4.",
            "The memo program, for a Token-2022 destination with `MemoTransfer` only (else pass the",
            "program id, Anchor's \"none\")."
          ],
          "optional": true,
          "address": "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr"
        },
        {
          "name": "eventAuthority"
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "shares",
          "type": "u128"
        },
        {
          "name": "minTokens",
          "type": "u64"
        },
        {
          "name": "minSol",
          "type": "u64"
        }
      ]
    }
  ],
  "accounts": [
    {
      "name": "globalConfig",
      "discriminator": [
        149,
        8,
        156,
        202,
        160,
        252,
        176,
        217
      ]
    },
    {
      "name": "lenderPosition",
      "discriminator": [
        165,
        98,
        244,
        204,
        209,
        158,
        88,
        19
      ]
    },
    {
      "name": "market",
      "discriminator": [
        219,
        190,
        213,
        55,
        0,
        227,
        198,
        154
      ]
    },
    {
      "name": "marketVault",
      "discriminator": [
        49,
        9,
        150,
        132,
        124,
        162,
        137,
        208
      ]
    },
    {
      "name": "oracleCache",
      "discriminator": [
        214,
        35,
        152,
        232,
        168,
        223,
        73,
        212
      ]
    },
    {
      "name": "priceReport",
      "discriminator": [
        26,
        139,
        144,
        41,
        36,
        16,
        187,
        8
      ]
    },
    {
      "name": "shortPosition",
      "discriminator": [
        110,
        216,
        100,
        57,
        75,
        53,
        168,
        59
      ]
    },
    {
      "name": "venueExtras",
      "discriminator": [
        206,
        206,
        44,
        22,
        14,
        20,
        114,
        102
      ]
    },
    {
      "name": "venueGuard",
      "discriminator": [
        23,
        82,
        203,
        19,
        118,
        120,
        140,
        146
      ]
    },
    {
      "name": "walletExposure",
      "discriminator": [
        96,
        91,
        128,
        118,
        104,
        144,
        64,
        198
      ]
    }
  ],
  "events": [
    {
      "name": "claimSol",
      "discriminator": [
        207,
        196,
        242,
        252,
        26,
        240,
        110,
        30
      ]
    },
    {
      "name": "close",
      "discriminator": [
        255,
        220,
        12,
        202,
        144,
        201,
        67,
        237
      ]
    },
    {
      "name": "configApplied",
      "discriminator": [
        193,
        101,
        90,
        205,
        113,
        125,
        184,
        13
      ]
    },
    {
      "name": "configCancelled",
      "discriminator": [
        230,
        230,
        7,
        76,
        157,
        223,
        168,
        244
      ]
    },
    {
      "name": "configProposed",
      "discriminator": [
        148,
        34,
        23,
        129,
        45,
        161,
        66,
        192
      ]
    },
    {
      "name": "coverageGap",
      "discriminator": [
        13,
        212,
        228,
        110,
        46,
        253,
        193,
        103
      ]
    },
    {
      "name": "coveragePauseSet",
      "discriminator": [
        65,
        72,
        33,
        170,
        50,
        110,
        14,
        82
      ]
    },
    {
      "name": "deficitCovered",
      "discriminator": [
        213,
        208,
        5,
        40,
        54,
        111,
        109,
        198
      ]
    },
    {
      "name": "deposit",
      "discriminator": [
        62,
        205,
        242,
        175,
        244,
        169,
        136,
        52
      ]
    },
    {
      "name": "epochRolled",
      "discriminator": [
        185,
        99,
        207,
        231,
        204,
        221,
        121,
        223
      ]
    },
    {
      "name": "expire",
      "discriminator": [
        234,
        255,
        38,
        74,
        163,
        225,
        3,
        148
      ]
    },
    {
      "name": "lenderSynced",
      "discriminator": [
        104,
        155,
        10,
        57,
        107,
        130,
        188,
        12
      ]
    },
    {
      "name": "liquidate",
      "discriminator": [
        82,
        165,
        82,
        245,
        248,
        64,
        66,
        30
      ]
    },
    {
      "name": "marginAdded",
      "discriminator": [
        121,
        187,
        28,
        95,
        195,
        171,
        37,
        8
      ]
    },
    {
      "name": "marketCreated",
      "discriminator": [
        88,
        184,
        130,
        231,
        226,
        84,
        6,
        58
      ]
    },
    {
      "name": "mintSafetyTripped",
      "discriminator": [
        24,
        107,
        61,
        0,
        29,
        226,
        183,
        92
      ]
    },
    {
      "name": "open",
      "discriminator": [
        104,
        220,
        224,
        191,
        87,
        241,
        132,
        61
      ]
    },
    {
      "name": "pauseSet",
      "discriminator": [
        175,
        57,
        198,
        136,
        192,
        66,
        204,
        73
      ]
    },
    {
      "name": "poolProposed",
      "discriminator": [
        240,
        227,
        132,
        153,
        249,
        229,
        150,
        22
      ]
    },
    {
      "name": "poolSwitchCancelled",
      "discriminator": [
        185,
        37,
        128,
        108,
        35,
        209,
        166,
        242
      ]
    },
    {
      "name": "poolSwitched",
      "discriminator": [
        131,
        130,
        118,
        215,
        190,
        83,
        232,
        162
      ]
    },
    {
      "name": "priceCranked",
      "discriminator": [
        23,
        58,
        76,
        217,
        123,
        34,
        141,
        128
      ]
    },
    {
      "name": "protocolFeesSwept",
      "discriminator": [
        233,
        66,
        206,
        184,
        30,
        100,
        130,
        85
      ]
    },
    {
      "name": "repay",
      "discriminator": [
        163,
        101,
        155,
        40,
        203,
        244,
        185,
        68
      ]
    },
    {
      "name": "routeBrokenSet",
      "discriminator": [
        151,
        29,
        197,
        249,
        24,
        110,
        113,
        250
      ]
    },
    {
      "name": "routeChainChanged",
      "discriminator": [
        45,
        150,
        16,
        125,
        247,
        248,
        11,
        2
      ]
    },
    {
      "name": "settleArmed",
      "discriminator": [
        230,
        163,
        201,
        158,
        38,
        181,
        136,
        62
      ]
    },
    {
      "name": "settleDisarmed",
      "discriminator": [
        245,
        52,
        133,
        39,
        189,
        147,
        123,
        235
      ]
    },
    {
      "name": "solSettle",
      "discriminator": [
        182,
        136,
        176,
        61,
        47,
        182,
        196,
        92
      ]
    },
    {
      "name": "traderSwept",
      "discriminator": [
        88,
        200,
        47,
        3,
        99,
        124,
        223,
        37
      ]
    },
    {
      "name": "venueDisabled",
      "discriminator": [
        40,
        49,
        102,
        195,
        69,
        254,
        221,
        60
      ]
    },
    {
      "name": "venueExtrasSet",
      "discriminator": [
        55,
        183,
        71,
        68,
        137,
        162,
        36,
        47
      ]
    },
    {
      "name": "venueRevalidated",
      "discriminator": [
        52,
        144,
        207,
        208,
        112,
        54,
        174,
        120
      ]
    },
    {
      "name": "venueRewardsClaimed",
      "discriminator": [
        33,
        196,
        20,
        199,
        3,
        49,
        41,
        146
      ]
    },
    {
      "name": "venueStateChanged",
      "discriminator": [
        239,
        40,
        254,
        189,
        27,
        139,
        175,
        31
      ]
    },
    {
      "name": "venueUpgradeFlagged",
      "discriminator": [
        145,
        235,
        160,
        213,
        77,
        160,
        242,
        42
      ]
    },
    {
      "name": "withdraw",
      "discriminator": [
        192,
        241,
        201,
        217,
        70,
        150,
        90,
        247
      ]
    }
  ],
  "errors": [
    {
      "code": 6000,
      "name": "mathOverflow",
      "msg": "Arithmetic overflow, underflow or an undefined value"
    },
    {
      "code": 6001,
      "name": "accountMismatch",
      "msg": "An account does not match the key, owner or state the instruction expects"
    },
    {
      "code": 6002,
      "name": "venueAccountMismatch",
      "msg": "A venue account does not match its compile-time, cached or re-derived key"
    },
    {
      "code": 6003,
      "name": "deniedAccount",
      "msg": "A protocol account was passed where it is denied (e.g. as a venue extra)"
    },
    {
      "code": 6004,
      "name": "badRemainingAccounts",
      "msg": "Remaining accounts are missing, extra or out of order"
    },
    {
      "code": 6005,
      "name": "badExtras",
      "msg": "A venue extras set or entry is invalid"
    },
    {
      "code": 6006,
      "name": "configVersion",
      "msg": "Account layout version is not the one this program expects"
    },
    {
      "code": 6007,
      "name": "epochRecordMismatch",
      "msg": "A ShareEpoch record does not match the market or epoch"
    },
    {
      "code": 6008,
      "name": "unauthorized",
      "msg": "Signer is not the authority this instruction requires"
    },
    {
      "code": 6009,
      "name": "timelockNotElapsed",
      "msg": "The pending config change is still timelocked"
    },
    {
      "code": 6010,
      "name": "noPendingChange",
      "msg": "There is no pending config change"
    },
    {
      "code": 6011,
      "name": "invalidParams",
      "msg": "A parameter is outside its compiled bounds or fails a relational check"
    },
    {
      "code": 6012,
      "name": "timelockTooShort",
      "msg": "Timelock is below the compiled minimum"
    },
    {
      "code": 6013,
      "name": "venueNotUpgraded",
      "msg": "The venue program's deploy slot has not changed"
    },
    {
      "code": 6014,
      "name": "venueSlotMismatch",
      "msg": "The venue program's deploy slot is not the expected slot"
    },
    {
      "code": 6015,
      "name": "coverageAuthorityDisabled",
      "msg": "The coverage authority is disabled"
    },
    {
      "code": 6016,
      "name": "mintUnsupportedProgram",
      "msg": "Mint is not owned by SPL Token or Token-2022"
    },
    {
      "code": 6017,
      "name": "mintNative",
      "msg": "Native (wrapped SOL) mints cannot be listed"
    },
    {
      "code": 6018,
      "name": "mintFreezeAuthority",
      "msg": "Mint has an active freeze authority"
    },
    {
      "code": 6019,
      "name": "mintDisallowedExtension",
      "msg": "Mint carries a Token-2022 extension that is not allowlisted (or unknown)"
    },
    {
      "code": 6020,
      "name": "mintMalformed",
      "msg": "Mint account data is malformed or uninitialized"
    },
    {
      "code": 6021,
      "name": "mintSafe",
      "msg": "Mint passes the safety filter"
    },
    {
      "code": 6022,
      "name": "mintUnsafeFlagged",
      "msg": "Mint has been flagged unsafe"
    },
    {
      "code": 6023,
      "name": "noSupportedVenue",
      "msg": "Market has no supported venue"
    },
    {
      "code": 6024,
      "name": "pumpVenuePrecedence",
      "msg": "Pump venues take precedence for this mint"
    },
    {
      "code": 6025,
      "name": "curveMayhemUnsupported",
      "msg": "Mayhem-mode curves and pools are not supported"
    },
    {
      "code": 6026,
      "name": "curveQuoteNotSol",
      "msg": "Curve quote mint is not SOL"
    },
    {
      "code": 6027,
      "name": "curveNeedsExtend",
      "msg": "Bonding curve account must be extended first"
    },
    {
      "code": 6028,
      "name": "venueMigrating",
      "msg": "Venue is migrating"
    },
    {
      "code": 6029,
      "name": "noRoute",
      "msg": "No executable route"
    },
    {
      "code": 6030,
      "name": "routeBroken",
      "msg": "Route is flagged broken"
    },
    {
      "code": 6031,
      "name": "curveStraddle",
      "msg": "Buyback exceeds what the curve and its post-migration pool can deliver"
    },
    {
      "code": 6032,
      "name": "venueDisabled",
      "msg": "Venue is disabled for opens"
    },
    {
      "code": 6033,
      "name": "venueUpgraded",
      "msg": "A venue program was upgraded and not yet re-validated"
    },
    {
      "code": 6034,
      "name": "venueFlagged",
      "msg": "Venue is flagged"
    },
    {
      "code": 6035,
      "name": "venueFeeTooHigh",
      "msg": "Venue fee is above the cap"
    },
    {
      "code": 6036,
      "name": "boostInProgress",
      "msg": "PumpSwap boost in progress"
    },
    {
      "code": 6037,
      "name": "venueResultMismatch",
      "msg": "Venue result does not match the quote or the expected deltas"
    },
    {
      "code": 6038,
      "name": "venueRentOnSell",
      "msg": "Venue took rent on a sell beyond the tolerance"
    },
    {
      "code": 6039,
      "name": "traderStateInvalid",
      "msg": "Trader state is invalid"
    },
    {
      "code": 6040,
      "name": "delegateNotCleared",
      "msg": "Pool vault delegate was not cleared"
    },
    {
      "code": 6041,
      "name": "authorityTampered",
      "msg": "An account authority was tampered with"
    },
    {
      "code": 6042,
      "name": "poolIneligible",
      "msg": "Pool is not eligible"
    },
    {
      "code": 6043,
      "name": "poolNotDominant",
      "msg": "Candidate pool does not dominate the incumbent"
    },
    {
      "code": 6044,
      "name": "positionsOpen",
      "msg": "Market has open positions"
    },
    {
      "code": 6045,
      "name": "poolSwitchNotDue",
      "msg": "Pool switch is not due"
    },
    {
      "code": 6046,
      "name": "noPendingSwitch",
      "msg": "No pending pool switch"
    },
    {
      "code": 6047,
      "name": "poolListWindow",
      "msg": "Opens wait for the pool listing window"
    },
    {
      "code": 6048,
      "name": "poolLockTooLow",
      "msg": "Locked LP share is too low"
    },
    {
      "code": 6049,
      "name": "poolTooThin",
      "msg": "Pool is too thin"
    },
    {
      "code": 6050,
      "name": "opensPaused",
      "msg": "Opens are paused"
    },
    {
      "code": 6051,
      "name": "coveragePaused",
      "msg": "Opens are paused for keeper coverage"
    },
    {
      "code": 6052,
      "name": "marketWarmingUp",
      "msg": "Market is warming up"
    },
    {
      "code": 6053,
      "name": "priceDeviatesFromEma",
      "msg": "Spot price deviates from the EMA"
    },
    {
      "code": 6054,
      "name": "priceAboveOpenMax",
      "msg": "EMA price is above the open maximum"
    },
    {
      "code": 6055,
      "name": "capPositionImpact",
      "msg": "Position impact cap exceeded"
    },
    {
      "code": 6056,
      "name": "capMarketOi",
      "msg": "Market open-interest cap exceeded"
    },
    {
      "code": 6057,
      "name": "capUtilization",
      "msg": "Utilisation cap exceeded"
    },
    {
      "code": 6058,
      "name": "capCurveGamma",
      "msg": "Curve gamma cap exceeded"
    },
    {
      "code": 6059,
      "name": "capWallet",
      "msg": "Wallet cap exceeded"
    },
    {
      "code": 6060,
      "name": "insufficientInventory",
      "msg": "Insufficient pool inventory"
    },
    {
      "code": 6061,
      "name": "belowMinNotional",
      "msg": "Notional below the minimum"
    },
    {
      "code": 6062,
      "name": "marketNotionalCap",
      "msg": "Market notional cap exceeded"
    },
    {
      "code": 6063,
      "name": "proceedsBelowMin",
      "msg": "Sale proceeds below the minimum"
    },
    {
      "code": 6064,
      "name": "marginAboveMax",
      "msg": "Margin above the maximum"
    },
    {
      "code": 6065,
      "name": "openFeeAboveMax",
      "msg": "Open fee above the maximum"
    },
    {
      "code": 6066,
      "name": "insufficientVault",
      "msg": "Vault SOL cannot cover the buyback, rent and tolerance"
    },
    {
      "code": 6067,
      "name": "buybackAboveMax",
      "msg": "Buyback cost above the maximum"
    },
    {
      "code": 6068,
      "name": "notLiquidatable",
      "msg": "Position is not liquidatable"
    },
    {
      "code": 6069,
      "name": "useSolSettle",
      "msg": "Normal buyback not allowed; use sol_settle"
    },
    {
      "code": 6070,
      "name": "useExpire",
      "msg": "Position is expired but not CR-liquidatable; use expire"
    },
    {
      "code": 6071,
      "name": "notExpired",
      "msg": "Position is not expired"
    },
    {
      "code": 6072,
      "name": "referenceStale",
      "msg": "No fresh completed observation bucket"
    },
    {
      "code": 6073,
      "name": "exitBoundNotMet",
      "msg": "Live buyback cost exceeds the exit bound"
    },
    {
      "code": 6074,
      "name": "settlementNotAllowed",
      "msg": "SOL settlement is not allowed"
    },
    {
      "code": 6075,
      "name": "s3TimerRunning",
      "msg": "S3 timer is still running"
    },
    {
      "code": 6076,
      "name": "zeroAmount",
      "msg": "Amount is zero"
    },
    {
      "code": 6077,
      "name": "sharesBelowMin",
      "msg": "Shares minted below the minimum"
    },
    {
      "code": 6078,
      "name": "tokensBelowMin",
      "msg": "Tokens withdrawn below the minimum"
    },
    {
      "code": 6079,
      "name": "insufficientShares",
      "msg": "Insufficient shares"
    },
    {
      "code": 6080,
      "name": "insufficientFreeInventory",
      "msg": "Insufficient free (unborrowed) inventory"
    },
    {
      "code": 6081,
      "name": "aboveProRataAllowance",
      "msg": "Withdrawal above the pro-rata allowance"
    },
    {
      "code": 6082,
      "name": "negativePending",
      "msg": "Lender SOL balance is negative; cover the deficit first"
    },
    {
      "code": 6083,
      "name": "lenderBehindEpochs",
      "msg": "Lender is behind the current share epoch; pass the ShareEpoch records or sync_lender"
    },
    {
      "code": 6084,
      "name": "wipeSweepPending",
      "msg": "Deposit waits for the post-wipe sweep and reward claim"
    },
    {
      "code": 6085,
      "name": "oracleOwner",
      "msg": "Oracle account owner is not the Pyth receiver"
    },
    {
      "code": 6086,
      "name": "oracleFeed",
      "msg": "Oracle account or feed id mismatch"
    },
    {
      "code": 6087,
      "name": "oracleStale",
      "msg": "Oracle price is stale or not newer than the cache"
    },
    {
      "code": 6088,
      "name": "oracleConfidence",
      "msg": "Oracle confidence too wide"
    },
    {
      "code": 6089,
      "name": "oracleStep",
      "msg": "Oracle price step too large"
    },
    {
      "code": 6090,
      "name": "oracleVerification",
      "msg": "Oracle update is not fully verified"
    },
    {
      "code": 6091,
      "name": "solBelowMin",
      "msg": "SOL paid below the minimum"
    },
    {
      "code": 6092,
      "name": "lastSharesBorrowed",
      "msg": "The last shares cannot be withdrawn while tokens are borrowed"
    },
    {
      "code": 6093,
      "name": "timelockTooLong",
      "msg": "Timelock is above the compiled maximum"
    },
    {
      "code": 6094,
      "name": "pendingChangeExpired",
      "msg": "The pending config change expired; propose it again"
    },
    {
      "code": 6095,
      "name": "memoProgramRequired",
      "msg": "The destination requires a memo: pass the memo program"
    },
    {
      "code": 6096,
      "name": "creationFeeAboveMax",
      "msg": "Market creation fee above the maximum"
    },
    {
      "code": 6097,
      "name": "oracleFutureDated",
      "msg": "Oracle publish time is in the future"
    },
    {
      "code": 6098,
      "name": "emergencyCannotCancel",
      "msg": "Only governance may cancel an authorities or timelock change"
    },
    {
      "code": 6099,
      "name": "useLiquidate",
      "msg": "Position is expired and CR-liquidatable; use liquidate"
    },
    {
      "code": 6100,
      "name": "poolWindowClosed",
      "msg": "The fast-path collection window has closed; call execute_pool_switch"
    },
    {
      "code": 6101,
      "name": "emaWarmingUp",
      "msg": "The price state is warming up after a venue change; opens and keeper exits wait"
    },
    {
      "code": 6102,
      "name": "carriedPositionsTooLarge",
      "msg": "An open position or the market's OI does not fit the candidate pool's opening caps"
    },
    {
      "code": 6103,
      "name": "reservedScanOutOfOrder",
      "msg": "Reserved (6103): unused"
    },
    {
      "code": 6104,
      "name": "graduationHalted",
      "msg": "PumpSwap pool creation is disabled (GlobalConfig.disable_flags bit 0), so this curve cannot graduate: new curve positions are refused until it is re-enabled; open positions are unaffected"
    },
    {
      "code": 6105,
      "name": "authoritiesNotDistinct",
      "msg": "governance, pause_authority, fee_recipient and coverage_authority must be pairwise distinct"
    },
    {
      "code": 6106,
      "name": "epochRecordReadOnly",
      "msg": "A ShareEpoch record the lender converts through must be passed writable"
    },
    {
      "code": 6107,
      "name": "rebaseNeedsOwner",
      "msg": "Only the position's owner may convert it through a rebase record: sync_lender must be signed by the owner"
    },
    {
      "code": 6108,
      "name": "poolDrained",
      "msg": "The pool is drained (at most 1/1,000 of its tokens unborrowed): deposits wait until repayments or settlements free more"
    },
    {
      "code": 6109,
      "name": "curveCashbackCoin",
      "msg": "pump.fun's current trades do not support cashback coins on the curve. This coin can be shorted once it graduates to PumpSwap."
    },
    {
      "code": 6110,
      "name": "legacyPoolCarry",
      "msg": "This empty pool has historical SOL carry: deposits require a reviewed migration"
    },
    {
      "code": 6111,
      "name": "repaymentRentAboveMax",
      "msg": "Accrued rent exceeds the borrower's repayment bound"
    }
  ],
  "types": [
    {
      "name": "claimSol",
      "docs": [
        "`claim_sol`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "amount",
            "docs": [
              "Tokens (deposit, withdraw) or lamports (cover)."
            ],
            "type": "u64"
          },
          {
            "name": "shares",
            "docs": [
              "Shares minted or burned."
            ],
            "type": "u128"
          },
          {
            "name": "tAfter",
            "docs": [
              "`T` after the instruction."
            ],
            "type": "u64"
          },
          {
            "name": "sAfter",
            "docs": [
              "`S` after the instruction."
            ],
            "type": "u128"
          },
          {
            "name": "solPaid",
            "docs": [
              "SOL paid to the lender."
            ],
            "type": "u64"
          },
          {
            "name": "potDraw",
            "docs": [
              "Of which drawn from the pot."
            ],
            "type": "u64"
          },
          {
            "name": "lock",
            "docs": [
              "The lender's lock after the instruction."
            ],
            "type": "u128"
          },
          {
            "name": "lockUntil",
            "type": "i64"
          },
          {
            "name": "epoch",
            "docs": [
              "The lender's share epoch after the instruction."
            ],
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "close",
      "docs": [
        "`close_short`. `b_live` (the execution quote the leg was bounded by, I13) and",
        "`token_surplus` (tokens a venue delivered beyond `q`, kept in the pool vault as a",
        "donation, A62, V2-10) are M2 additions to ARCH §3.10's field list."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "borrower",
            "type": "pubkey"
          },
          {
            "name": "q",
            "type": "u64"
          },
          {
            "name": "buybackCost",
            "type": "u64"
          },
          {
            "name": "rent",
            "type": "u64"
          },
          {
            "name": "rentProtocol",
            "type": "u64"
          },
          {
            "name": "borrowerPayout",
            "type": "u64"
          },
          {
            "name": "bLive",
            "type": "u64"
          },
          {
            "name": "tokenSurplus",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "configApplied",
      "docs": [
        "`apply_config`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "kind",
            "type": "u8"
          },
          {
            "name": "hash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          }
        ]
      }
    },
    {
      "name": "configCancelled",
      "docs": [
        "`cancel_config`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "kind",
            "type": "u8"
          },
          {
            "name": "hash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "by",
            "docs": [
              "Who cancelled (Governance or Emergency)."
            ],
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "configChange",
      "docs": [
        "A governance change (ARCH §3.1 `propose_config`). **There is no variant that changes a",
        "venue program id or a venue PDA (C0-8).**"
      ],
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "params",
            "fields": [
              {
                "name": "params",
                "type": {
                  "defined": {
                    "name": "params"
                  }
                }
              },
              {
                "name": "tiers",
                "type": {
                  "array": [
                    {
                      "defined": {
                        "name": "tierParams"
                      }
                    },
                    4
                  ]
                }
              }
            ]
          },
          {
            "name": "emaParams",
            "fields": [
              {
                "name": "ema",
                "type": {
                  "defined": {
                    "name": "emaParamsArgs"
                  }
                }
              }
            ]
          },
          {
            "name": "kink",
            "fields": [
              {
                "name": "utilKinkBps",
                "type": "u32"
              }
            ]
          },
          {
            "name": "authorities",
            "fields": [
              {
                "name": "governance",
                "type": "pubkey"
              },
              {
                "name": "pauseAuthority",
                "type": "pubkey"
              },
              {
                "name": "coverageAuthority",
                "type": "pubkey"
              },
              {
                "name": "feeRecipient",
                "type": "pubkey"
              }
            ]
          },
          {
            "name": "timelock",
            "fields": [
              {
                "name": "timelockS",
                "type": "u32"
              }
            ]
          },
          {
            "name": "enableVenues",
            "fields": [
              {
                "name": "bits",
                "type": "u32"
              }
            ]
          },
          {
            "name": "oracleFeed",
            "fields": [
              {
                "name": "account",
                "type": "pubkey"
              },
              {
                "name": "feedId",
                "type": {
                  "array": [
                    "u8",
                    32
                  ]
                }
              }
            ]
          }
        ]
      }
    },
    {
      "name": "configProposed",
      "docs": [
        "`propose_config`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "kind",
            "docs": [
              "`ConfigChange` kind (variant index + 1)."
            ],
            "type": "u8"
          },
          {
            "name": "hash",
            "docs": [
              "`sha256(kind ‖ payload)`."
            ],
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "notBefore",
            "type": "i64"
          }
        ]
      }
    },
    {
      "name": "coverageGap",
      "docs": [
        "A bucket integration found the EMA older than `COVERAGE_GAP_S` with open positions",
        "(`emit!`, not `emit_cpi!`; A69)."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "gapS",
            "type": "i64"
          },
          {
            "name": "openPositions",
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "coveragePauseSet",
      "docs": [
        "`set_coverage_pause` (O17): `paused_coverage` set or cleared on `market` by `by` (the",
        "`coverage_authority`, or — a clear only, OWNER-M7-3 — the Emergency vault `pause_authority`),",
        "with the reason code ([`COVERAGE_REASON_KEEPER`])."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "paused",
            "type": "bool"
          },
          {
            "name": "reason",
            "type": "u8"
          },
          {
            "name": "by",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "deficitCovered",
      "docs": [
        "`cover_deficit`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "amount",
            "docs": [
              "Tokens (deposit, withdraw) or lamports (cover)."
            ],
            "type": "u64"
          },
          {
            "name": "shares",
            "docs": [
              "Shares minted or burned."
            ],
            "type": "u128"
          },
          {
            "name": "tAfter",
            "docs": [
              "`T` after the instruction."
            ],
            "type": "u64"
          },
          {
            "name": "sAfter",
            "docs": [
              "`S` after the instruction."
            ],
            "type": "u128"
          },
          {
            "name": "solPaid",
            "docs": [
              "SOL paid to the lender."
            ],
            "type": "u64"
          },
          {
            "name": "potDraw",
            "docs": [
              "Of which drawn from the pot."
            ],
            "type": "u64"
          },
          {
            "name": "lock",
            "docs": [
              "The lender's lock after the instruction."
            ],
            "type": "u128"
          },
          {
            "name": "lockUntil",
            "type": "i64"
          },
          {
            "name": "epoch",
            "docs": [
              "The lender's share epoch after the instruction."
            ],
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "deposit",
      "docs": [
        "`deposit`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "amount",
            "docs": [
              "Tokens (deposit, withdraw) or lamports (cover)."
            ],
            "type": "u64"
          },
          {
            "name": "shares",
            "docs": [
              "Shares minted or burned."
            ],
            "type": "u128"
          },
          {
            "name": "tAfter",
            "docs": [
              "`T` after the instruction."
            ],
            "type": "u64"
          },
          {
            "name": "sAfter",
            "docs": [
              "`S` after the instruction."
            ],
            "type": "u128"
          },
          {
            "name": "solPaid",
            "docs": [
              "SOL paid to the lender."
            ],
            "type": "u64"
          },
          {
            "name": "potDraw",
            "docs": [
              "Of which drawn from the pot."
            ],
            "type": "u64"
          },
          {
            "name": "lock",
            "docs": [
              "The lender's lock after the instruction."
            ],
            "type": "u128"
          },
          {
            "name": "lockUntil",
            "type": "i64"
          },
          {
            "name": "epoch",
            "docs": [
              "The lender's share epoch after the instruction."
            ],
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "emaConfig",
      "docs": [
        "`GlobalConfig.ema_params` (ARCH §2.3.2), 32 B: a market adopts a new `version` while it has",
        "no open position, or at its first prologue after `force_at` (A17, A59; V2-13)."
      ],
      "serialization": "bytemuck",
      "repr": {
        "kind": "c"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "emaDtmaxS",
            "type": "u16"
          },
          {
            "name": "pad0",
            "type": {
              "array": [
                "u8",
                2
              ]
            }
          },
          {
            "name": "emaClampBps",
            "type": "u32"
          },
          {
            "name": "liqSlowTauS",
            "type": "u32"
          },
          {
            "name": "liqSlowDtmaxS",
            "type": "u32"
          },
          {
            "name": "version",
            "type": "u32"
          },
          {
            "name": "pad1",
            "type": {
              "array": [
                "u8",
                4
              ]
            }
          },
          {
            "name": "forceAt",
            "type": "i64"
          }
        ]
      }
    },
    {
      "name": "emaParamsArgs",
      "docs": [
        "The market-level EMA parameter values (ARCH §2.3.2 `ema_params` without version and",
        "`force_at`): the argument form of `initialize_config` and of `ConfigChange::EmaParams`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "emaDtmaxS",
            "type": "u16"
          },
          {
            "name": "emaClampBps",
            "type": "u32"
          },
          {
            "name": "liqSlowTauS",
            "type": "u32"
          },
          {
            "name": "liqSlowDtmaxS",
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "epochRolled",
      "docs": [
        "A share-epoch roll."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "epoch",
            "type": "u32"
          },
          {
            "name": "accEnd",
            "type": "i128"
          },
          {
            "name": "num",
            "type": "u8"
          },
          {
            "name": "den",
            "docs": [
              "`1,000^k`."
            ],
            "type": "u128"
          },
          {
            "name": "vestFlushed",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "expire",
      "docs": [
        "`expire`. `b_live` is the execution quote the leg was bounded by (I13). `b_live_risk` (the",
        "fee base with `b_ref`), `max_in` (I11) and `token_surplus` (tokens a venue delivered beyond",
        "`q`, A62, V2-10) are M2 additions to ARCH §3.10's field list."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "keeper",
            "type": "pubkey"
          },
          {
            "name": "bLive",
            "type": "u64"
          },
          {
            "name": "bRef",
            "type": "u64"
          },
          {
            "name": "piRef",
            "type": "u64"
          },
          {
            "name": "buybackCost",
            "type": "u64"
          },
          {
            "name": "rent",
            "type": "u64"
          },
          {
            "name": "expiryFee",
            "type": "u64"
          },
          {
            "name": "keeperReward",
            "type": "u64"
          },
          {
            "name": "borrowerPayout",
            "type": "u64"
          },
          {
            "name": "bLiveRisk",
            "type": "u64"
          },
          {
            "name": "maxIn",
            "type": "u64"
          },
          {
            "name": "tokenSurplus",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "extraEntry",
      "docs": [
        "One trailing account (176 B)."
      ],
      "serialization": "bytemuck",
      "repr": {
        "kind": "c"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "kind",
            "docs": [
              "`ENTRY_NONE`, `ENTRY_FIXED` or `ENTRY_TEMPLATE`."
            ],
            "type": "u8"
          },
          {
            "name": "writable",
            "docs": [
              "1 if the account is passed writable."
            ],
            "type": "u8"
          },
          {
            "name": "nSeeds",
            "docs": [
              "Seed parts used (template)."
            ],
            "type": "u8"
          },
          {
            "name": "pad",
            "type": {
              "array": [
                "u8",
                5
              ]
            }
          },
          {
            "name": "key",
            "docs": [
              "The fixed key, or the template's program."
            ],
            "type": "pubkey"
          },
          {
            "name": "seeds",
            "type": {
              "array": [
                {
                  "defined": {
                    "name": "seedPart"
                  }
                },
                4
              ]
            }
          }
        ]
      }
    },
    {
      "name": "extraEntryArg",
      "docs": [
        "One trailing account, as the argument encoding of [`ExtraEntry`]: `kind` 1 = a fixed `key`,",
        "2 = a template derived under program `key` from `seeds`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "kind",
            "type": "u8"
          },
          {
            "name": "writable",
            "type": "bool"
          },
          {
            "name": "key",
            "type": "pubkey"
          },
          {
            "name": "seeds",
            "type": {
              "vec": {
                "defined": {
                  "name": "seedPartArg"
                }
              }
            }
          }
        ]
      }
    },
    {
      "name": "extrasSel",
      "docs": [
        "The extras set a trading instruction selects (ARCH §3.0 \"Bounded extras\", A41): `set`",
        "([`EXTRAS_SET_NONE`], [`EXTRAS_SET_CURRENT`], [`EXTRAS_SET_PREVIOUS`],",
        "[`EXTRAS_SET_STABLE`]) and, for each",
        "template entry `i`, the canonical bump `bumps[i]` of the account it derives (fixed entries",
        "ignore theirs; a non-canonical bump is `BadExtras`, M2-SEC-3)."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "set",
            "type": "u8"
          },
          {
            "name": "bumps",
            "type": {
              "array": [
                "u8",
                4
              ]
            }
          }
        ]
      }
    },
    {
      "name": "extrasSet",
      "docs": [
        "A set of up to 4 entries with its version (712 B)."
      ],
      "serialization": "bytemuck",
      "repr": {
        "kind": "c"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "version",
            "type": "u32"
          },
          {
            "name": "count",
            "docs": [
              "Entries used."
            ],
            "type": "u8"
          },
          {
            "name": "pad",
            "type": {
              "array": [
                "u8",
                3
              ]
            }
          },
          {
            "name": "entries",
            "type": {
              "array": [
                {
                  "defined": {
                    "name": "extraEntry"
                  }
                },
                4
              ]
            }
          }
        ]
      }
    },
    {
      "name": "globalConfig",
      "docs": [
        "The global configuration (ARCH §2.3.2)."
      ],
      "serialization": "bytemuck",
      "repr": {
        "kind": "c"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "version",
            "docs": [
              "Layout version ([`crate::constants::CONFIG_VERSION`])."
            ],
            "type": "u16"
          },
          {
            "name": "bump",
            "docs": [
              "PDA bump of `[\"config\"]`."
            ],
            "type": "u8"
          },
          {
            "name": "flags",
            "docs": [
              "Bit 0 [`CONFIG_FLAG_PAUSED_OPENS`]."
            ],
            "type": "u8"
          },
          {
            "name": "venueEnabled",
            "docs": [
              "Venues enabled for opens (`VENUE_BIT_*`). Enabling is timelocked (`EnableVenues`),",
              "disabling immediate (`disable_venue`); affects opens only."
            ],
            "type": "u32"
          },
          {
            "name": "venueRouteBroken",
            "docs": [
              "Route-broken venues (same bits; Emergency, O6 — built in M2). Opens and S3 evidence",
              "only (A40)."
            ],
            "type": "u32"
          },
          {
            "name": "timelockS",
            "docs": [
              "Governance timelock, seconds (`MIN_TIMELOCK_S ≤ timelock_s ≤ MAX_TIMELOCK_S`)."
            ],
            "type": "u32"
          },
          {
            "name": "paramsVersion",
            "docs": [
              "Incremented by every applied `Params` change."
            ],
            "type": "u32"
          },
          {
            "name": "pad0",
            "type": {
              "array": [
                "u8",
                4
              ]
            }
          },
          {
            "name": "governance",
            "docs": [
              "Squads Governance vault (48 h Squads time lock)."
            ],
            "type": "pubkey"
          },
          {
            "name": "pauseAuthority",
            "docs": [
              "Squads Emergency vault (time lock 0)."
            ],
            "type": "pubkey"
          },
          {
            "name": "coverageAuthority",
            "docs": [
              "Keeper key that may only set/clear a market's `paused_coverage` (`set_coverage_pause`;",
              "A69, O17). `Pubkey::default()` = the role disabled (the `initialize_config` default);",
              "governance installs or rotates it with a timelocked `Authorities` change."
            ],
            "type": "pubkey"
          },
          {
            "name": "feeRecipient",
            "docs": [
              "Destination of `sweep_protocol_fees`."
            ],
            "type": "pubkey"
          },
          {
            "name": "pythSolUsd",
            "docs": [
              "Pyth `PriceUpdateV2` account read by `crank_sol_usd`."
            ],
            "type": "pubkey"
          },
          {
            "name": "pythFeedId",
            "docs": [
              "Pyth feed id of SOL/USD."
            ],
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "params",
            "docs": [
              "Global parameters (scopes G and G→P)."
            ],
            "type": {
              "defined": {
                "name": "params"
              }
            }
          },
          {
            "name": "tiers",
            "docs": [
              "Tier parameters A, B, C, D."
            ],
            "type": {
              "array": [
                {
                  "defined": {
                    "name": "tierParams"
                  }
                },
                4
              ]
            }
          },
          {
            "name": "emaParams",
            "docs": [
              "Market-level EMA parameters with their version and forced-adoption time (A17, A59)."
            ],
            "type": {
              "defined": {
                "name": "emaConfig"
              }
            }
          },
          {
            "name": "kink",
            "docs": [
              "Market-level rent-curve kink with its own version (R3A-9)."
            ],
            "type": {
              "defined": {
                "name": "kinkConfig"
              }
            }
          },
          {
            "name": "pending",
            "docs": [
              "The pending governance change (at most one)."
            ],
            "type": {
              "defined": {
                "name": "pendingChange"
              }
            }
          },
          {
            "name": "reserved",
            "type": {
              "array": [
                "u8",
                256
              ]
            }
          }
        ]
      }
    },
    {
      "name": "initConfigArgs",
      "docs": [
        "The initial configuration (ARCH §3.1 `initialize_config`)."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "governance",
            "type": "pubkey"
          },
          {
            "name": "pauseAuthority",
            "type": "pubkey"
          },
          {
            "name": "coverageAuthority",
            "docs": [
              "`Pubkey::default()` = disabled (the default until O17)."
            ],
            "type": "pubkey"
          },
          {
            "name": "feeRecipient",
            "type": "pubkey"
          },
          {
            "name": "pythSolUsd",
            "type": "pubkey"
          },
          {
            "name": "pythFeedId",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "timelockS",
            "docs": [
              "In `[MIN_TIMELOCK_S, MAX_TIMELOCK_S]`."
            ],
            "type": "u32"
          },
          {
            "name": "venueEnabled",
            "docs": [
              "Venue bits enabled for opens (`VENUE_BIT_*`)."
            ],
            "type": "u32"
          },
          {
            "name": "params",
            "type": {
              "defined": {
                "name": "params"
              }
            }
          },
          {
            "name": "tiers",
            "type": {
              "array": [
                {
                  "defined": {
                    "name": "tierParams"
                  }
                },
                4
              ]
            }
          },
          {
            "name": "ema",
            "type": {
              "defined": {
                "name": "emaParamsArgs"
              }
            }
          },
          {
            "name": "utilKinkBps",
            "type": "u32"
          },
          {
            "name": "guardSlot",
            "docs": [
              "`VenueGuard.guard_slot`: the ProgramData deploy slots validated at launch, in",
              "`VenueGuard` order (pump, pAMM, pfee, AMM v4, CPMM, Jupiter)."
            ],
            "type": {
              "array": [
                "u64",
                6
              ]
            }
          }
        ]
      }
    },
    {
      "name": "initializePriceReportArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "genesisHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "quantity",
            "type": "u64"
          },
          {
            "name": "model",
            "type": {
              "defined": {
                "name": "priceReportModelArgs"
              }
            }
          },
          {
            "name": "policy",
            "type": {
              "defined": {
                "name": "priceReportPolicyArgs"
              }
            }
          },
          {
            "name": "publisherCount",
            "type": "u8"
          },
          {
            "name": "publishers",
            "type": {
              "array": [
                "pubkey",
                8
              ]
            }
          }
        ]
      }
    },
    {
      "name": "ixExtras",
      "docs": [
        "The selectable sets of one instruction kind (2,144 B)."
      ],
      "serialization": "bytemuck",
      "repr": {
        "kind": "c"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "current",
            "type": {
              "defined": {
                "name": "extrasSet"
              }
            }
          },
          {
            "name": "previous",
            "docs": [
              "The set the last write displaced."
            ],
            "type": {
              "defined": {
                "name": "extrasSet"
              }
            }
          },
          {
            "name": "stable",
            "docs": [
              "The newest set that stood as `current` for `EXTRAS_STABLE_S` before being displaced,",
              "or Governance's last publication (M2-SEC-2; module docs)."
            ],
            "type": {
              "defined": {
                "name": "extrasSet"
              }
            }
          },
          {
            "name": "currentSince",
            "docs": [
              "When `current` was written (unix seconds; 0: never, the empty set of",
              "`initialize_config`)."
            ],
            "type": "i64"
          }
        ]
      }
    },
    {
      "name": "kinkConfig",
      "docs": [
        "`GlobalConfig.kink` (ARCH §2.3.2), 8 B: market-level with its own version, adopted only",
        "while a market has no open position (R3A-9)."
      ],
      "serialization": "bytemuck",
      "repr": {
        "kind": "c"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "utilKinkBps",
            "type": "u32"
          },
          {
            "name": "version",
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "lenderPosition",
      "docs": [
        "A lender's position in one market (ARCH §2.3.6)."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "shares",
            "docs": [
              "Shares, in units of `epoch`."
            ],
            "type": "u128"
          },
          {
            "name": "snap",
            "docs": [
              "`acc` snapshot."
            ],
            "type": "i128"
          },
          {
            "name": "pending",
            "docs": [
              "Entitlement not yet paid (negative after a shortfall debit, ECON §9.4)."
            ],
            "type": "i64"
          },
          {
            "name": "snapR",
            "docs": [
              "`acc_r` snapshot."
            ],
            "type": "u128"
          },
          {
            "name": "real",
            "docs": [
              "Cumulative realised SOL allocated to this lender, including pot draws (V2-2)."
            ],
            "type": "u64"
          },
          {
            "name": "claimed",
            "docs": [
              "Cumulative SOL paid to this lender (V2-2)."
            ],
            "type": "u64"
          },
          {
            "name": "epoch",
            "docs": [
              "Share epoch of `shares`."
            ],
            "type": "u32"
          },
          {
            "name": "lock",
            "docs": [
              "Locked shares at `lock_pi` (ECON §9.3)."
            ],
            "type": "u128"
          },
          {
            "name": "lockPi",
            "docs": [
              "Π when the lock was set."
            ],
            "type": "u128"
          },
          {
            "name": "lockEpoch",
            "docs": [
              "Π epoch of `lock` (`u32::MAX` = no lock)."
            ],
            "type": "u32"
          },
          {
            "name": "lockTerm",
            "docs": [
              "The lock's term in the calendar bucket of `lock_until`."
            ],
            "type": "u128"
          },
          {
            "name": "lockUntil",
            "docs": [
              "When the lock expires (a calendar day end; R3B-1, R4A-2)."
            ],
            "type": "i64"
          },
          {
            "name": "bump",
            "type": "u8"
          },
          {
            "name": "fwdShares",
            "docs": [
              "KI-66 full: the forward chain's shares in `fwd_epoch` (`pool::Lender::fwd_shares`; 0",
              "without a chain)."
            ],
            "type": "u128"
          },
          {
            "name": "fwdEpoch",
            "docs": [
              "KI-66 full: the epoch the forward chain reached (0 without a chain)."
            ],
            "type": "u32"
          },
          {
            "name": "fwd",
            "docs": [
              "KI-66 full: `pool::FWD_NONE` / `FWD_HOLD` / `FWD_OPEN`; while not `FWD_NONE`, `snap` /",
              "`snap_r` are the chain's snapshots (module docs)."
            ],
            "type": "u8"
          },
          {
            "name": "fwdLag",
            "docs": [
              "KI-66 full, `FWD_OPEN`: `shares` minus the chain's shares in `epoch` (0 or 1)."
            ],
            "type": "u8"
          },
          {
            "name": "reserved",
            "type": {
              "array": [
                "u8",
                10
              ]
            }
          }
        ]
      }
    },
    {
      "name": "lenderSynced",
      "docs": [
        "`sync_lender`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "amount",
            "docs": [
              "Tokens (deposit, withdraw) or lamports (cover)."
            ],
            "type": "u64"
          },
          {
            "name": "shares",
            "docs": [
              "Shares minted or burned."
            ],
            "type": "u128"
          },
          {
            "name": "tAfter",
            "docs": [
              "`T` after the instruction."
            ],
            "type": "u64"
          },
          {
            "name": "sAfter",
            "docs": [
              "`S` after the instruction."
            ],
            "type": "u128"
          },
          {
            "name": "solPaid",
            "docs": [
              "SOL paid to the lender."
            ],
            "type": "u64"
          },
          {
            "name": "potDraw",
            "docs": [
              "Of which drawn from the pot."
            ],
            "type": "u64"
          },
          {
            "name": "lock",
            "docs": [
              "The lender's lock after the instruction."
            ],
            "type": "u128"
          },
          {
            "name": "lockUntil",
            "type": "i64"
          },
          {
            "name": "epoch",
            "docs": [
              "The lender's share epoch after the instruction."
            ],
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "liquidate",
      "docs": [
        "`liquidate`. `cr_spot_bps` is the robust spot leg's CR (`CR(V_eff, B̂(Q; reprice(max(L_live,",
        "L_ema'), P_rs)))` at the risk fee; FITS-2), `cr_ema_bps` the newest ring entry's (its cached",
        "`(x, y)`);",
        "`b_live` is the execution quote the leg was bounded by (I13). `b_live_risk` (the live",
        "quote at the risk fee, the penalty's base with `b_ref`) and `max_in` (I11: `B ≤ max_in +",
        "ert`) are M2 additions to ARCH §3.10's field list."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "keeper",
            "type": "pubkey"
          },
          {
            "name": "crSpotBps",
            "type": "u64"
          },
          {
            "name": "crEmaBps",
            "type": "u64"
          },
          {
            "name": "bLive",
            "type": "u64"
          },
          {
            "name": "bRef",
            "type": "u64"
          },
          {
            "name": "pRef",
            "type": "u128"
          },
          {
            "name": "deltaBps",
            "docs": [
              "The fixed δ."
            ],
            "type": "u16"
          },
          {
            "name": "buybackCost",
            "type": "u64"
          },
          {
            "name": "rent",
            "type": "u64"
          },
          {
            "name": "penalty",
            "type": "u64"
          },
          {
            "name": "penaltyLender",
            "type": "u64"
          },
          {
            "name": "penaltyProtocol",
            "type": "u64"
          },
          {
            "name": "penaltyKeeper",
            "type": "u64"
          },
          {
            "name": "keeperTopup",
            "type": "u64"
          },
          {
            "name": "borrowerPayout",
            "type": "u64"
          },
          {
            "name": "expired",
            "type": "bool"
          },
          {
            "name": "tokenSurplus",
            "type": "u64"
          },
          {
            "name": "bLiveRisk",
            "type": "u64"
          },
          {
            "name": "maxIn",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "marginAdded",
      "docs": [
        "`add_margin`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "amount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "market",
      "docs": [
        "A market: one per mint (ARCH §2.3.4)."
      ],
      "serialization": "bytemuck",
      "repr": {
        "kind": "c"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "version",
            "docs": [
              "Layout version ([`crate::constants::MARKET_VERSION`])."
            ],
            "type": "u16"
          },
          {
            "name": "flags",
            "docs": [
              "`MARKET_FLAG_*`."
            ],
            "type": "u16"
          },
          {
            "name": "bump",
            "type": "u8"
          },
          {
            "name": "poolVaultBump",
            "type": "u8"
          },
          {
            "name": "marketVaultBump",
            "type": "u8"
          },
          {
            "name": "traderBump",
            "type": "u8"
          },
          {
            "name": "traderWsolBump",
            "type": "u8"
          },
          {
            "name": "venue",
            "docs": [
              "[`VenueKind`] as `u8`."
            ],
            "type": "u8"
          },
          {
            "name": "tier",
            "docs": [
              "Cached tier (`shortwin_math::tier::Tier` as `u8`)."
            ],
            "type": "u8"
          },
          {
            "name": "decimals",
            "docs": [
              "Mint decimals."
            ],
            "type": "u8"
          },
          {
            "name": "ringHead",
            "type": "u8"
          },
          {
            "name": "ringCount",
            "type": "u8"
          },
          {
            "name": "emaWarm",
            "docs": [
              "Integrations left in the post-change warm-up (M4R, **PROPOSED**, owner item O18; was",
              "`_pad0[0]`): `EMA_WARMUP_BUCKETS` after a restart (a Raydium adoption or listing), counted",
              "down by the prologue's roll; `0` = confirmed (every account created before M4R). While it",
              "is positive on an executable venue opens, `liquidate` and `expire` refuse `EmaWarmingUp`",
              "and `sol_settle` evaluates nothing (`shortwin_math::observe::Ema::warm`)."
            ],
            "type": "u8"
          },
          {
            "name": "emaGuard",
            "docs": [
              "`1` while the post-change reference guard is set (M4R; was `_pad0[1]`): the keeper exits'",
              "reference liquidity reads `min(L_ema, L_mlo)` (`shortwin_math::bounds::ref_liquidity`)."
            ],
            "type": "u8"
          },
          {
            "name": "createdAt",
            "type": "i64"
          },
          {
            "name": "mint",
            "type": "pubkey"
          },
          {
            "name": "tokenProgram",
            "type": "pubkey"
          },
          {
            "name": "creator",
            "type": "pubkey"
          },
          {
            "name": "poolVault",
            "type": "pubkey"
          },
          {
            "name": "marketVault",
            "type": "pubkey"
          },
          {
            "name": "trader",
            "type": "pubkey"
          },
          {
            "name": "traderBaseAta",
            "type": "pubkey"
          },
          {
            "name": "traderWsol",
            "type": "pubkey"
          },
          {
            "name": "bondingCurve",
            "type": "pubkey"
          },
          {
            "name": "canonicalPool",
            "type": "pubkey"
          },
          {
            "name": "curveBaseAta",
            "type": "pubkey"
          },
          {
            "name": "curveQuoteAta",
            "type": "pubkey"
          },
          {
            "name": "sharingConfig",
            "type": "pubkey"
          },
          {
            "name": "pumpUva",
            "type": "pubkey"
          },
          {
            "name": "pumpUvaQuoteAta",
            "type": "pubkey"
          },
          {
            "name": "cachedCreator",
            "type": "pubkey"
          },
          {
            "name": "cachedCreatorVault",
            "type": "pubkey"
          },
          {
            "name": "cachedCreatorVaultAta",
            "type": "pubkey"
          },
          {
            "name": "poolCache",
            "type": {
              "array": [
                "pubkey",
                10
              ]
            }
          },
          {
            "name": "poolSeenAt",
            "type": "i64"
          },
          {
            "name": "poolD",
            "docs": [
              "Incumbent locked depth `D`."
            ],
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "fpKeys",
            "docs": [
              "Fast-path window: best candidate's keys."
            ],
            "type": {
              "array": [
                "pubkey",
                6
              ]
            }
          },
          {
            "name": "fpD",
            "docs": [
              "Fast-path window: best candidate's `D`."
            ],
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "fpT0",
            "type": "i64"
          },
          {
            "name": "fpVenue",
            "type": "u8"
          },
          {
            "name": "pad1",
            "type": "u8"
          },
          {
            "name": "pad1a",
            "docs": [
              "Retired `fp_lambda_bps` (M4-SEC-5's record of the candidate's `λ`; M4R: an adoption reads",
              "no sample of the pool): padding, zeroed by `clear_window`."
            ],
            "type": {
              "array": [
                "u8",
                2
              ]
            }
          },
          {
            "name": "pad1b",
            "type": {
              "array": [
                "u8",
                4
              ]
            }
          },
          {
            "name": "migrationSeenAt",
            "type": "i64"
          },
          {
            "name": "graduatedAt",
            "type": "i64"
          },
          {
            "name": "tierComputedAt",
            "type": "i64"
          },
          {
            "name": "noRouteSince",
            "type": "i64"
          },
          {
            "name": "lastNoRouteObs",
            "type": "i64"
          },
          {
            "name": "poolFailSince",
            "type": "i64"
          },
          {
            "name": "lastPoolFailObs",
            "type": "i64"
          },
          {
            "name": "tokensFree",
            "docs": [
              "`T`: unborrowed tokens (internal counter; donations ignored)."
            ],
            "type": "u64"
          },
          {
            "name": "borrowedQ",
            "docs": [
              "`ΣB_Q`."
            ],
            "type": "u64"
          },
          {
            "name": "borrowedQByTier",
            "type": {
              "array": [
                "u64",
                4
              ]
            }
          },
          {
            "name": "totalShares",
            "docs": [
              "`S`."
            ],
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "acc",
            "type": {
              "defined": {
                "name": "podI128"
              }
            }
          },
          {
            "name": "carry",
            "type": {
              "defined": {
                "name": "podI128"
              }
            }
          },
          {
            "name": "accR",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "carryR",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "dust",
            "type": {
              "defined": {
                "name": "podI128"
              }
            }
          },
          {
            "name": "receivable",
            "type": "u64"
          },
          {
            "name": "maxRelease",
            "type": "i64"
          },
          {
            "name": "vestBal",
            "type": "u64"
          },
          {
            "name": "vestLast",
            "type": "i64"
          },
          {
            "name": "vestEnd",
            "type": "i64"
          },
          {
            "name": "shareEpoch",
            "type": "u32"
          },
          {
            "name": "pad2",
            "type": {
              "array": [
                "u8",
                4
              ]
            }
          },
          {
            "name": "rentBasis",
            "docs": [
              "`J0, J1, J2`."
            ],
            "type": {
              "array": [
                {
                  "defined": {
                    "name": "podU128"
                  }
                },
                3
              ]
            }
          },
          {
            "name": "rentAggr",
            "docs": [
              "`A_j = Σ Q·coef_j·(10⁴ − p_pos)`."
            ],
            "type": {
              "array": [
                {
                  "defined": {
                    "name": "podU128"
                  }
                },
                3
              ]
            }
          },
          {
            "name": "lastAccrualTs",
            "type": "i64"
          },
          {
            "name": "bSec",
            "type": "i64"
          },
          {
            "name": "bLo",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "bHi",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "bLlo",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "bLhi",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "lbSec",
            "type": "i64"
          },
          {
            "name": "lbLo",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "lbHi",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "emaPrice",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "emaLiq",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "liqSlow",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "emaTs",
            "type": "i64"
          },
          {
            "name": "slowTs",
            "type": "i64"
          },
          {
            "name": "emaCount",
            "type": "u64"
          },
          {
            "name": "ring",
            "type": {
              "array": [
                {
                  "defined": {
                    "name": "ringEntry"
                  }
                },
                8
              ]
            }
          },
          {
            "name": "emaParamsVersion",
            "type": "u32"
          },
          {
            "name": "kinkVersion",
            "type": "u32"
          },
          {
            "name": "emaClampBps",
            "type": "u32"
          },
          {
            "name": "utilKinkBps",
            "type": "u32"
          },
          {
            "name": "liqSlowTauS",
            "type": "u32"
          },
          {
            "name": "liqSlowDtmaxS",
            "type": "u32"
          },
          {
            "name": "emaDtmaxS",
            "type": "u16"
          },
          {
            "name": "pad3",
            "type": {
              "array": [
                "u8",
                6
              ]
            }
          },
          {
            "name": "openPositions",
            "type": "u32"
          },
          {
            "name": "pad4",
            "type": {
              "array": [
                "u8",
                4
              ]
            }
          },
          {
            "name": "totalNotionalOpen",
            "type": "u64"
          },
          {
            "name": "maxQHwm",
            "docs": [
              "High-water mark of `q` over the positions opened since `open_positions` last returned to 0",
              "(was `_reserved[0..8]`; owner decision of 2026-09-29, \"switch only if all fit\"): raised by",
              "every open (`engine::waterfall::add_position`), reset to 0 by the exit that takes",
              "`open_positions` to 0 (`remove_position`), so it is at least every open position's `q` —",
              "conservative by design (a position that has closed may have set it). A pool adoption that",
              "carries open positions checks `min(max_q_hwm, ΣB_Q)` against the candidate's per-position",
              "caps in O(1) (`shortwin_math::caps::carried_fit`; `engine::pool_select::carried_fit`)."
            ],
            "type": "u64"
          },
          {
            "name": "minOpenFeePpm",
            "docs": [
              "Low-water mark of the one-way venue fee φ (ppm) the opens since `open_positions` last",
              "returned to 0 paid — the fee their caps were computed at and their margin posted at (was",
              "`_reserved[8..12]`; FIT-2): set by the first open after the market emptied, lowered by every",
              "later one (`engine::waterfall::add_position`, `shortwin_math::caps::open_fee_mark`), reset",
              "to 0 with `max_q_hwm` (`remove_position`). The carried fit's fee-scaled caps take",
              "`min(min_open_fee_ppm, φ_cand, CARRIED_FEE_CAP_PPM)` (`shortwin_math::caps::carried_phi`;",
              "`engine::pool_select::carried_caps`; FITS-1: 25 bps), so a position carried onto a",
              "higher-fee pool stays in the size class of the fee it was margined at, and none above the",
              "25-bps class."
            ],
            "type": "u32"
          },
          {
            "name": "pad5",
            "type": {
              "array": [
                "u8",
                4
              ]
            }
          },
          {
            "name": "traderWsolAta",
            "docs": [
              "`ATA(trader, WSOL)` under SPL Token (the pump curve's TradeExtras T11, `sweep_trader`'s",
              "stray-ATA slot): derived once at listing instead of on every trade. The trader is the",
              "market's PDA, so a coin's creator who grinds the mint can give this ATA a low bump, and",
              "`find_program_address` charges 1,500 CU per bump it tries (M5-SEC-6)."
            ],
            "type": "pubkey"
          },
          {
            "name": "pumpPoolAuthority",
            "docs": [
              "`PDA(pump, [\"pool-authority\", mint])`, the canonical PumpSwap pool's `creator`, which",
              "`canonical_pool_valid` compares (ARCH §2.5); derived once at listing for the same reason."
            ],
            "type": "pubkey"
          },
          {
            "name": "coverageClearedAt",
            "docs": [
              "M7-SEC-3 (was `_reserved[0..8]`): the unix second `set_coverage_pause(false)` last cleared",
              "a set `paused_coverage` flag (signed by the coverage key or, since OWNER-M7-3, the Emergency",
              "vault). `open_short` refuses until `COVERAGE_CLEAR_DELAY_S` after it",
              "(`CoveragePaused`; `engine::guard::open_static`), so the `coverage_authority` key cannot",
              "bracket an open on a coverage-paused market — `[clear, open_short, set]` in one",
              "transaction or one second — and the flag stays visibly cleared for the keeper's reads",
              "before any open can land. 0 on existing accounts (no delay)."
            ],
            "type": "i64"
          },
          {
            "name": "lenderCreditRem",
            "docs": [
              "AIR-03 (was `_reserved[0..16]`): the remainder of the last accrual's lender rent credit,",
              "`(Σ_j A_j·δJ_j + rem) mod (10⁴·10⁴·31,536,000·WAD)` (`shortwin_math::rent::",
              "lender_credit_carried`, `engine::prologue::accrue`), carried into the next accrual so the",
              "credits sum to the floor of their exact total instead of flooring each accrual alone (a",
              "market cranked every second lost up to a lamport a second, which the exits' true-ups",
              "left in `lender_sol`). Always below that denominator; 0 on existing accounts."
            ],
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "minOpenHardCapBps",
            "docs": [
              "AIR-19 (was `_reserved[16..18]`): low-water mark of the `venue_fee_hard_cap_bps` the",
              "positions opened since `open_positions` last returned to 0 locked — set by the first open",
              "after the market emptied, lowered by every later one (`engine::waterfall::add_position`),",
              "reset to 0 by the exit that takes `open_positions` to 0 (`remove_position`), so it is at",
              "most every open position's locked cap (conservative by design: a position that has",
              "closed may have set it). The market's S3 chain counts a live fee above",
              "`min(global cap, this mark)` as no route (`engine::route::s3_no_route`), so a position",
              "whose locked cap is below a raised global cap reaches S3 when the fee passes its own cap.",
              "0 (unset) on existing accounts: the global cap alone, as before."
            ],
            "type": "u16"
          },
          {
            "name": "pad6",
            "type": {
              "array": [
                "u8",
                6
              ]
            }
          },
          {
            "name": "depositHoldUntil",
            "docs": [
              "Initial vest end after a settlement leaves a vest. Deposits wait until the shared vest",
              "actually reaches 0, because later credits can move its end. -1 means initialized with",
              "no hold; 0 means legacy/uninitialized. First accrual invalidates legacy source bits and",
              "arms the hold; pending venue rewards also arm it before a split claim can re-vest income.",
              "The next successful deposit after release sets -1. Carved from `_reserved`."
            ],
            "type": "i64"
          },
          {
            "name": "restartEmaCount",
            "docs": [
              "First EMA count belonging to the latest observation restart (restart count + 1).",
              "Settlement arms from an earlier count must rearm, even if nobody touched them during",
              "warm-up. Zero on legacy markets until their first full prologue. Carved from `_reserved`."
            ],
            "type": "u64"
          },
          {
            "name": "reserved",
            "type": {
              "array": [
                "u8",
                128
              ]
            }
          }
        ]
      }
    },
    {
      "name": "marketCreated",
      "docs": [
        "`create_market`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "mint",
            "type": "pubkey"
          },
          {
            "name": "tokenProgram",
            "type": "pubkey"
          },
          {
            "name": "venue",
            "type": "u8"
          },
          {
            "name": "creator",
            "type": "pubkey"
          },
          {
            "name": "bondingCurve",
            "type": "pubkey"
          },
          {
            "name": "canonicalPool",
            "type": "pubkey"
          },
          {
            "name": "rayPool",
            "docs": [
              "Raydium pool adopted at listing (`Pubkey::default()` otherwise)."
            ],
            "type": "pubkey"
          },
          {
            "name": "tier",
            "type": "u8"
          },
          {
            "name": "creationFee",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "marketVault",
      "docs": [
        "The market's SOL float and lock state."
      ],
      "serialization": "bytemuck",
      "repr": {
        "kind": "c"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "lenderSol",
            "docs": [
              "Realised lender SOL (ECON `sol_vault`), including the pot and the unreleased vest."
            ],
            "type": "u64"
          },
          {
            "name": "unmatched",
            "docs": [
              "The pot: realised SOL beyond its receivers' entitlement (R3A-2)."
            ],
            "type": "u64"
          },
          {
            "name": "protocolFees",
            "docs": [
              "Protocol fees awaiting `sweep_protocol_fees`."
            ],
            "type": "u64"
          },
          {
            "name": "pi",
            "docs": [
              "Π (WAD)."
            ],
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "lockNorm",
            "docs": [
              "Σ of the live calendar buckets."
            ],
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "bMin",
            "docs": [
              "Running minimum of `ΣB_Q` since the first lock of the Π epoch (V2-3)."
            ],
            "type": "u64"
          },
          {
            "name": "piEpoch",
            "type": "u32"
          },
          {
            "name": "bump",
            "docs": [
              "PDA bump of `[\"market_vault\", market]`."
            ],
            "type": "u8"
          },
          {
            "name": "pad0",
            "type": {
              "array": [
                "u8",
                3
              ]
            }
          },
          {
            "name": "calDay",
            "docs": [
              "Oldest calendar day not yet dropped."
            ],
            "type": "i64"
          },
          {
            "name": "lockCal",
            "docs": [
              "Lock expiry calendar (128 day buckets)."
            ],
            "type": {
              "array": [
                {
                  "defined": {
                    "name": "podU128"
                  }
                },
                128
              ]
            }
          },
          {
            "name": "reserved",
            "type": {
              "array": [
                "u8",
                64
              ]
            }
          }
        ]
      }
    },
    {
      "name": "mintSafetyTripped",
      "docs": [
        "The mint failed the safety filter (`flag_unsafe_mint`, or an exit path's tripwire)."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "mint",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "open",
      "docs": [
        "`open_short`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "borrower",
            "type": "pubkey"
          },
          {
            "name": "nonce",
            "type": "u64"
          },
          {
            "name": "q",
            "type": "u64"
          },
          {
            "name": "s",
            "type": "u64"
          },
          {
            "name": "m",
            "type": "u64"
          },
          {
            "name": "v",
            "type": "u64"
          },
          {
            "name": "nOpen",
            "type": "u64"
          },
          {
            "name": "feeOpen",
            "type": "u64"
          },
          {
            "name": "tier",
            "type": "u8"
          },
          {
            "name": "entryPrice",
            "type": "u128"
          },
          {
            "name": "spotWad",
            "type": "u128"
          },
          {
            "name": "emaWad",
            "type": "u128"
          },
          {
            "name": "bSpot",
            "type": "u64"
          },
          {
            "name": "bEma",
            "type": "u64"
          },
          {
            "name": "deadline",
            "type": "i64"
          },
          {
            "name": "venue",
            "type": "u8"
          },
          {
            "name": "venueRent",
            "docs": [
              "PumpSwap venue-side rent `r` (V1-13); 0 elsewhere."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "oracleCache",
      "docs": [
        "The cached Pyth SOL/USD price."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "price",
            "docs": [
              "Price in units of `10^expo` USD."
            ],
            "type": "i64"
          },
          {
            "name": "conf",
            "type": "u64"
          },
          {
            "name": "expo",
            "type": "i32"
          },
          {
            "name": "publishTime",
            "docs": [
              "Pyth publish time (unix seconds); 0 = never cranked."
            ],
            "type": "i64"
          },
          {
            "name": "updatedSlot",
            "type": "u64"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "params",
      "docs": [
        "Global parameters in account form (ARCH §2.3.3; the values of `shortwin_math::params::Params`",
        "except `util_kink_bps`, which lives in [`KinkConfig`]).",
        "",
        "Fields are grouped by width (u64, then u32, then u16) so the struct has no padding at all",
        "(264 B) and its Borsh encoding (instruction arguments) equals its memory layout (account).",
        "Five fields are wider here than in the math crate (`settle_persist_n`, `settle_arm_gap_s`",
        "u32; `ref_max_age_s`, `liq_persist_n`, `kappa_growth_n` u16); [`Params::to_math`] narrows",
        "them with a checked conversion, so an out-of-range value is `InvalidParams`."
      ],
      "repr": {
        "kind": "c"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "settleKeeperFixed",
            "type": "u64"
          },
          {
            "name": "settleKeeperCap",
            "type": "u64"
          },
          {
            "name": "expiryKeeperFixed",
            "type": "u64"
          },
          {
            "name": "expiryKeeperCap",
            "type": "u64"
          },
          {
            "name": "minNotional",
            "type": "u64"
          },
          {
            "name": "marketMaxNotional",
            "type": "u64"
          },
          {
            "name": "marketCreationFee",
            "type": "u64"
          },
          {
            "name": "boostDustLamports",
            "type": "u64"
          },
          {
            "name": "execRentTol",
            "type": "u64"
          },
          {
            "name": "thetaAUsdE6",
            "type": "u64"
          },
          {
            "name": "thetaBUsdE6",
            "type": "u64"
          },
          {
            "name": "poolMinRealSol",
            "type": "u64"
          },
          {
            "name": "openFeeBps",
            "type": "u32"
          },
          {
            "name": "rentProtocolBps",
            "type": "u32"
          },
          {
            "name": "penaltyLenderBps",
            "type": "u32"
          },
          {
            "name": "penaltyProtocolBps",
            "type": "u32"
          },
          {
            "name": "penaltyKeeperBps",
            "type": "u32"
          },
          {
            "name": "expiryFeeBps",
            "type": "u32"
          },
          {
            "name": "settleKeeperBps",
            "type": "u32"
          },
          {
            "name": "expiryKeeperBps",
            "type": "u32"
          },
          {
            "name": "utilCapBps",
            "type": "u32"
          },
          {
            "name": "walletCapBps",
            "type": "u32"
          },
          {
            "name": "curveOiGammaBps",
            "type": "u32"
          },
          {
            "name": "feeSizeCapX100",
            "type": "u32"
          },
          {
            "name": "feeOiCapX100",
            "type": "u32"
          },
          {
            "name": "s3WaitS",
            "type": "u32"
          },
          {
            "name": "gradGraceS",
            "type": "u32"
          },
          {
            "name": "maxMigrationPauseS",
            "type": "u32"
          },
          {
            "name": "boostWindowS",
            "type": "u32"
          },
          {
            "name": "openEmaDevBps",
            "type": "u32"
          },
          {
            "name": "marketWarmupS",
            "type": "u32"
          },
          {
            "name": "emaForceDelayS",
            "type": "u32"
          },
          {
            "name": "settlePersistN",
            "type": "u32"
          },
          {
            "name": "settleArmGapS",
            "type": "u32"
          },
          {
            "name": "fvDevBps",
            "type": "u32"
          },
          {
            "name": "lumpVestS",
            "type": "u32"
          },
          {
            "name": "lockGraceS",
            "type": "u32"
          },
          {
            "name": "oracleMaxAgeS",
            "type": "u32"
          },
          {
            "name": "oracleStaleS",
            "type": "u32"
          },
          {
            "name": "oracleMaxConfBps",
            "type": "u32"
          },
          {
            "name": "oracleMaxStepBps",
            "type": "u32"
          },
          {
            "name": "venueFeeCapBps",
            "type": "u32"
          },
          {
            "name": "venueFeeHardCapBps",
            "type": "u32"
          },
          {
            "name": "poolLockMinBps",
            "type": "u32"
          },
          {
            "name": "poolSwitchMarginBps",
            "type": "u32"
          },
          {
            "name": "poolListWindowS",
            "type": "u32"
          },
          {
            "name": "poolListMarginBps",
            "type": "u32"
          },
          {
            "name": "poolFastRouteS",
            "type": "u32"
          },
          {
            "name": "poolFastMinBps",
            "type": "u32"
          },
          {
            "name": "poolFastWindowS",
            "type": "u32"
          },
          {
            "name": "kappaLiqBps",
            "type": "u16"
          },
          {
            "name": "kappaBaseBps",
            "type": "u16"
          },
          {
            "name": "deltaLiqBps",
            "type": "u16"
          },
          {
            "name": "deltaExpBps",
            "type": "u16"
          },
          {
            "name": "execTolBps",
            "type": "u16"
          },
          {
            "name": "refMaxAgeS",
            "type": "u16"
          },
          {
            "name": "liqPersistN",
            "type": "u16"
          },
          {
            "name": "kappaGrowthN",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "pauseScope",
      "docs": [
        "What `set_pause` pauses."
      ],
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "global"
          },
          {
            "name": "market"
          }
        ]
      }
    },
    {
      "name": "pauseSet",
      "docs": [
        "`set_pause`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "scope",
            "docs": [
              "[`SCOPE_GLOBAL`] or [`SCOPE_MARKET`]."
            ],
            "type": "u8"
          },
          {
            "name": "paused",
            "type": "bool"
          },
          {
            "name": "by",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "pendingChange",
      "docs": [
        "`GlobalConfig.pending` (ARCH §2.3.2), 472 B: `kind` 0 = none, else the [`ConfigChange`]",
        "variant index + 1; `payload` is the Borsh encoding of that variant's fields (the",
        "`ConfigChange` encoding without its one-byte tag), zero-padded to [`PENDING_PAYLOAD_LEN`]."
      ],
      "serialization": "bytemuck",
      "repr": {
        "kind": "c"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "kind",
            "type": "u8"
          },
          {
            "name": "pad",
            "type": {
              "array": [
                "u8",
                7
              ]
            }
          },
          {
            "name": "notBefore",
            "type": "i64"
          },
          {
            "name": "payload",
            "type": {
              "array": [
                "u8",
                456
              ]
            }
          }
        ]
      }
    },
    {
      "name": "podI128",
      "docs": [
        "Signed 128-bit value (two's complement), 16 little-endian bytes, alignment 1."
      ],
      "repr": {
        "kind": "transparent"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "array": [
              "u8",
              16
            ]
          }
        ]
      }
    },
    {
      "name": "podU128",
      "docs": [
        "Unsigned 128-bit value, 16 little-endian bytes, alignment 1."
      ],
      "repr": {
        "kind": "transparent"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "array": [
              "u8",
              16
            ]
          }
        ]
      }
    },
    {
      "name": "poolProposed",
      "docs": [
        "`propose_pool` opened or improved a fast-path collection window (ARCH §2.6 rule 3)."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "candidate",
            "docs": [
              "The candidate pool (`PoolSwitched`: the pool now adopted)."
            ],
            "type": "pubkey"
          },
          {
            "name": "kind",
            "docs": [
              "`POOL_KIND_*`: listing / listing window / zero-position / fast."
            ],
            "type": "u8"
          },
          {
            "name": "dCand",
            "docs": [
              "The candidate's locked depth `D` (`PoolSwitchCancelled`: the best one seen)."
            ],
            "type": "u128"
          },
          {
            "name": "dInc",
            "docs": [
              "The incumbent's locked depth `pool_d` (0 for a list-only market)."
            ],
            "type": "u128"
          },
          {
            "name": "windowEnds",
            "docs": [
              "`PoolProposed` / `PoolSwitchCancelled`: the end of the fast-path collection",
              "window; `PoolSwitched`: the end of the listing window after the adoption (opens",
              "resume then)."
            ],
            "type": "i64"
          }
        ]
      }
    },
    {
      "name": "poolSwitchCancelled",
      "docs": [
        "A collection window closed without adoption (`execute_pool_switch`, ARCH §2.6 rule 3):",
        "the window's candidate is no longer eligible or no longer passes the window floor (its",
        "locked SOL at `P_ema`, M4V-1); on a Raydium market the `pool_fail` chain that armed the",
        "window broke — the incumbent no longer fails `pool_fail`, or it recovered and failed",
        "again (M4-SEC-2); on a list-only market its detection set now shows a pump venue (D1,",
        "M4-SEC-4); or the candidate's own Raydium program is flagged in the venue-upgrade latch",
        "(M4V-4: not adoptable now; the chain stays armed)."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "candidate",
            "docs": [
              "The candidate pool (`PoolSwitched`: the pool now adopted)."
            ],
            "type": "pubkey"
          },
          {
            "name": "kind",
            "docs": [
              "`POOL_KIND_*`: listing / listing window / zero-position / fast."
            ],
            "type": "u8"
          },
          {
            "name": "dCand",
            "docs": [
              "The candidate's locked depth `D` (`PoolSwitchCancelled`: the best one seen)."
            ],
            "type": "u128"
          },
          {
            "name": "dInc",
            "docs": [
              "The incumbent's locked depth `pool_d` (0 for a list-only market)."
            ],
            "type": "u128"
          },
          {
            "name": "windowEnds",
            "docs": [
              "`PoolProposed` / `PoolSwitchCancelled`: the end of the fast-path collection",
              "window; `PoolSwitched`: the end of the listing window after the adoption (opens",
              "resume then)."
            ],
            "type": "i64"
          }
        ]
      }
    },
    {
      "name": "poolSwitched",
      "docs": [
        "A pool adoption (`propose_pool`: listing, listing window, zero-position;",
        "`execute_pool_switch`: fast path). ARCH §2.6 rule 4."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "candidate",
            "docs": [
              "The candidate pool (`PoolSwitched`: the pool now adopted)."
            ],
            "type": "pubkey"
          },
          {
            "name": "kind",
            "docs": [
              "`POOL_KIND_*`: listing / listing window / zero-position / fast."
            ],
            "type": "u8"
          },
          {
            "name": "dCand",
            "docs": [
              "The candidate's locked depth `D` (`PoolSwitchCancelled`: the best one seen)."
            ],
            "type": "u128"
          },
          {
            "name": "dInc",
            "docs": [
              "The incumbent's locked depth `pool_d` (0 for a list-only market)."
            ],
            "type": "u128"
          },
          {
            "name": "windowEnds",
            "docs": [
              "`PoolProposed` / `PoolSwitchCancelled`: the end of the fast-path collection",
              "window; `PoolSwitched`: the end of the listing window after the adoption (opens",
              "resume then)."
            ],
            "type": "i64"
          }
        ]
      }
    },
    {
      "name": "priceCranked",
      "docs": [
        "`crank_price`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "spotWad",
            "type": "u128"
          },
          {
            "name": "emaPrice",
            "type": "u128"
          },
          {
            "name": "emaLiq",
            "type": "u128"
          },
          {
            "name": "liqSlow",
            "type": "u128"
          },
          {
            "name": "emaCount",
            "type": "u64"
          },
          {
            "name": "lbLo",
            "type": "u128"
          },
          {
            "name": "lbHi",
            "type": "u128"
          },
          {
            "name": "tier",
            "type": "u8"
          },
          {
            "name": "utilBps",
            "type": "u32"
          },
          {
            "name": "rentBasis",
            "type": {
              "array": [
                "u128",
                3
              ]
            }
          },
          {
            "name": "vestBal",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "priceReport",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "version",
            "type": "u16"
          },
          {
            "name": "bump",
            "type": "u8"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "quantity",
            "type": "u64"
          },
          {
            "name": "modelEpoch",
            "type": "u64"
          },
          {
            "name": "stateBytes",
            "type": {
              "array": [
                "u8",
                1488
              ]
            }
          }
        ]
      }
    },
    {
      "name": "priceReportDomainArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "genesisHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "program",
            "type": "pubkey"
          },
          {
            "name": "config",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "baseMint",
            "type": "pubkey"
          },
          {
            "name": "baseTokenProgram",
            "type": "pubkey"
          },
          {
            "name": "quoteMint",
            "type": "pubkey"
          },
          {
            "name": "quoteTokenProgram",
            "type": "pubkey"
          },
          {
            "name": "baseDecimals",
            "type": "u8"
          },
          {
            "name": "quoteDecimals",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "priceReportModelArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "version",
            "type": "u32"
          },
          {
            "name": "epoch",
            "type": "u64"
          },
          {
            "name": "policyHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          }
        ]
      }
    },
    {
      "name": "priceReportPolicyArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "maxAgeSlots",
            "type": "u64"
          },
          {
            "name": "maxAgeSeconds",
            "type": "u64"
          },
          {
            "name": "maxWindowSlots",
            "type": "u64"
          },
          {
            "name": "maxWindowSeconds",
            "type": "u64"
          },
          {
            "name": "maxUpdateGapSlots",
            "type": "u64"
          },
          {
            "name": "maxUpdateGapSeconds",
            "type": "u64"
          },
          {
            "name": "epochSeconds",
            "type": "u64"
          },
          {
            "name": "minimumCompletedEpochs",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "priceReportStatusArgs",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "unknown"
          },
          {
            "name": "finite",
            "fields": [
              {
                "name": "lower",
                "type": "u64"
              },
              {
                "name": "central",
                "type": "u64"
              },
              {
                "name": "upper",
                "type": "u64"
              }
            ]
          }
        ]
      }
    },
    {
      "name": "protocolFeesSwept",
      "docs": [
        "`sweep_protocol_fees`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "amount",
            "type": "u64"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "publishPriceReportArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "version",
            "type": "u16"
          },
          {
            "name": "domain",
            "type": {
              "defined": {
                "name": "priceReportDomainArgs"
              }
            }
          },
          {
            "name": "quantity",
            "type": "u64"
          },
          {
            "name": "model",
            "type": {
              "defined": {
                "name": "priceReportModelArgs"
              }
            }
          },
          {
            "name": "configurationEpoch",
            "type": "u64"
          },
          {
            "name": "publisher",
            "type": "pubkey"
          },
          {
            "name": "sequence",
            "type": "u64"
          },
          {
            "name": "startSlot",
            "type": "u64"
          },
          {
            "name": "startTs",
            "type": "i64"
          },
          {
            "name": "endSlot",
            "type": "u64"
          },
          {
            "name": "endTs",
            "type": "i64"
          },
          {
            "name": "observationDigest",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "status",
            "type": {
              "defined": {
                "name": "priceReportStatusArgs"
              }
            }
          }
        ]
      }
    },
    {
      "name": "repay",
      "docs": [
        "Borrower supplies all debt tokens without an oracle or swap. External acquisition",
        "cost is not observed; readers must not interpret this as a zero-cost trading profit."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "borrower",
            "type": "pubkey"
          },
          {
            "name": "q",
            "type": "u64"
          },
          {
            "name": "rent",
            "type": "u64"
          },
          {
            "name": "rentProtocol",
            "type": "u64"
          },
          {
            "name": "borrowerPayout",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "ringEntry",
      "docs": [
        "One EMA ring entry (ARCH §2.3.4; 136 B): `(x, y) = reprice(l, p)` cached at integration;",
        "`(lo, hi, llo, lhi)` the integrated bucket's price and liquidity extremes (R4B-2)."
      ],
      "serialization": "bytemuck",
      "repr": {
        "kind": "c"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "p",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "l",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "x",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "y",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "lo",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "hi",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "llo",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          },
          {
            "name": "lhi",
            "type": {
              "defined": {
                "name": "podU128"
              }
            }
          }
        ]
      }
    },
    {
      "name": "routeBrokenSet",
      "docs": [
        "`set_route_broken` (O6; M2)."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "scope",
            "type": "u8"
          },
          {
            "name": "venueBit",
            "docs": [
              "`venue_enabled`-style bit index for the global scope."
            ],
            "type": "u8"
          },
          {
            "name": "broken",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "routeChainChanged",
      "docs": [
        "A route chain (S3 or fast path) changed."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "noRouteSince",
            "type": "i64"
          },
          {
            "name": "lastNoRouteObs",
            "type": "i64"
          },
          {
            "name": "poolFailSince",
            "type": "i64"
          },
          {
            "name": "lastPoolFailObs",
            "type": "i64"
          }
        ]
      }
    },
    {
      "name": "seedPart",
      "docs": [
        "One seed of a derivation template (34 B)."
      ],
      "serialization": "bytemuck",
      "repr": {
        "kind": "c"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "kind",
            "docs": [
              "`SEED_NONE`, `SEED_CONST` or `SEED_PLACEHOLDER`."
            ],
            "type": "u8"
          },
          {
            "name": "len",
            "docs": [
              "Constant: number of bytes used; placeholder: `PLACEHOLDER_*`."
            ],
            "type": "u8"
          },
          {
            "name": "bytes",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          }
        ]
      }
    },
    {
      "name": "seedPartArg",
      "docs": [
        "One seed of a template, as the argument encoding of [`SeedPart`]: `kind` 1 = constant",
        "(`len` bytes of `bytes`), 2 = placeholder (`len` = the placeholder id, `bytes` zero)."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "kind",
            "type": "u8"
          },
          {
            "name": "len",
            "type": "u8"
          },
          {
            "name": "bytes",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          }
        ]
      }
    },
    {
      "name": "settleArmed",
      "docs": [
        "`sol_settle` armed the clock."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "sCount",
            "type": "u64"
          },
          {
            "name": "sSince",
            "type": "i64"
          },
          {
            "name": "reason",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "settleDisarmed",
      "docs": [
        "`sol_settle` disarmed the clock."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "sCount",
            "type": "u64"
          },
          {
            "name": "sSince",
            "type": "i64"
          },
          {
            "name": "reason",
            "docs": [
              "[`SETTLE_REASON_REFUTED`] or [`SETTLE_REASON_NOT_LIQUIDATABLE`]."
            ],
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "shortPosition",
      "docs": [
        "A short position (ARCH §2.3.5)."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "borrower",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "nonce",
            "docs": [
              "Chosen by the client; `init` fails if reused."
            ],
            "type": "u64"
          },
          {
            "name": "bump",
            "type": "u8"
          },
          {
            "name": "status",
            "docs": [
              "[`POSITION_OPEN`] (1 = ExitInProgress reserved for v1.1)."
            ],
            "type": "u8"
          },
          {
            "name": "tier",
            "type": "u8"
          },
          {
            "name": "venueAtOpen",
            "type": "u8"
          },
          {
            "name": "q",
            "docs": [
              "Tokens owed (constant: no partial close in the MVP)."
            ],
            "type": "u64"
          },
          {
            "name": "s",
            "docs": [
              "Sale proceeds."
            ],
            "type": "u64"
          },
          {
            "name": "m",
            "docs": [
              "Margin."
            ],
            "type": "u64"
          },
          {
            "name": "v",
            "docs": [
              "Tracked vault lamports (changes only through `add_margin`)."
            ],
            "type": "u64"
          },
          {
            "name": "nOpen",
            "type": "u64"
          },
          {
            "name": "feeOpen",
            "type": "u64"
          },
          {
            "name": "entryPrice",
            "docs": [
              "`S·WAD/Q`."
            ],
            "type": "u128"
          },
          {
            "name": "jOpen",
            "docs": [
              "Rent basis indices at open."
            ],
            "type": {
              "array": [
                "u128",
                3
              ]
            }
          },
          {
            "name": "rMin",
            "docs": [
              "Minimum rent, fixed at open."
            ],
            "type": "u64"
          },
          {
            "name": "tOpen",
            "type": "i64"
          },
          {
            "name": "deadline",
            "docs": [
              "`t_open + max_duration_s[tier]`."
            ],
            "type": "i64"
          },
          {
            "name": "crLiqBps",
            "type": "u32"
          },
          {
            "name": "penaltyBps",
            "type": "u16"
          },
          {
            "name": "maxLiqSlipBps",
            "type": "u16"
          },
          {
            "name": "expiryFeeBps",
            "type": "u16"
          },
          {
            "name": "rateBaseBps",
            "type": "u32"
          },
          {
            "name": "rateSlope1Bps",
            "type": "u32"
          },
          {
            "name": "rateSlope2Bps",
            "type": "u32"
          },
          {
            "name": "penaltySplit",
            "docs": [
              "Lender / protocol / keeper."
            ],
            "type": {
              "array": [
                "u16",
                3
              ]
            }
          },
          {
            "name": "rentProtocolBps",
            "type": "u16"
          },
          {
            "name": "settleKeeperFixed",
            "type": "u64"
          },
          {
            "name": "settleKeeperBps",
            "type": "u16"
          },
          {
            "name": "settleKeeperCap",
            "type": "u64"
          },
          {
            "name": "expiryKeeperFixed",
            "type": "u64"
          },
          {
            "name": "expiryKeeperBps",
            "type": "u16"
          },
          {
            "name": "expiryKeeperCap",
            "type": "u64"
          },
          {
            "name": "deltaLiqBps",
            "type": "u16"
          },
          {
            "name": "deltaExpBps",
            "type": "u16"
          },
          {
            "name": "kappaLiqBps",
            "type": "u16"
          },
          {
            "name": "kappaBaseBps",
            "type": "u16"
          },
          {
            "name": "kappaGrowthN",
            "type": "u8"
          },
          {
            "name": "liqPersistN",
            "type": "u8"
          },
          {
            "name": "settlePersistN",
            "type": "u16"
          },
          {
            "name": "settleArmGapS",
            "type": "u16"
          },
          {
            "name": "execTolBps",
            "docs": [
              "ε of the expiry bound."
            ],
            "type": "u16"
          },
          {
            "name": "ert",
            "docs": [
              "Effective `exec_rent_tol` (0 on Raydium)."
            ],
            "type": "u64"
          },
          {
            "name": "refMaxAgeS",
            "type": "u8"
          },
          {
            "name": "fvDevBps",
            "type": "u16"
          },
          {
            "name": "venueFeeHardCapBps",
            "type": "u16"
          },
          {
            "name": "s3WaitS",
            "type": "u32"
          },
          {
            "name": "gradGraceS",
            "type": "u32"
          },
          {
            "name": "maxMigrationPauseS",
            "type": "u32"
          },
          {
            "name": "sArmed",
            "type": "u8"
          },
          {
            "name": "sCount",
            "docs": [
              "`ema_count` at arm."
            ],
            "type": "u64"
          },
          {
            "name": "sSince",
            "type": "i64"
          },
          {
            "name": "sLast",
            "type": "i64"
          },
          {
            "name": "reserved",
            "docs": [
              "Room for the O1/O2 terms if the owner ever signs them off (not built, R3A-8 c)."
            ],
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          }
        ]
      }
    },
    {
      "name": "solSettle",
      "docs": [
        "`sol_settle` (an executing settlement). `vest_flushed` (AIR-07) is an addition to ARCH",
        "§3.10's field list."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "keeper",
            "type": "pubkey"
          },
          {
            "name": "condition",
            "docs": [
              "1 = S1, 2 = S2, 3 = S3."
            ],
            "type": "u8"
          },
          {
            "name": "bLive",
            "type": "u64"
          },
          {
            "name": "bRs",
            "type": "u64"
          },
          {
            "name": "bEma",
            "type": "u64"
          },
          {
            "name": "pLo",
            "type": "u128"
          },
          {
            "name": "pHi",
            "type": "u128"
          },
          {
            "name": "lLo",
            "type": "u128"
          },
          {
            "name": "lHi",
            "type": "u128"
          },
          {
            "name": "xLo",
            "type": "u64"
          },
          {
            "name": "xHi",
            "type": "u64"
          },
          {
            "name": "pprimeLo",
            "type": "u16"
          },
          {
            "name": "pprimeHi",
            "type": "u16"
          },
          {
            "name": "fv",
            "type": "u64"
          },
          {
            "name": "kS",
            "type": "u64"
          },
          {
            "name": "lenderAmount",
            "type": "u64"
          },
          {
            "name": "lump",
            "type": "u64"
          },
          {
            "name": "borrowerAmount",
            "type": "u64"
          },
          {
            "name": "emaAgeS",
            "docs": [
              "`now − ema_ts` (V2-5)."
            ],
            "type": "i64"
          },
          {
            "name": "vestFlushed",
            "docs": [
              "The unreleased vest the settlement paid to the shares at once, its own lump and rent",
              "top-up included: it left at most 1/1,000 of the token claims it found, a full wipe",
              "included (AIR-07). Reported with or without an epoch roll (`EpochRolled.vest_flushed`",
              "repeats it); 0 when nothing was flushed."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "tierParams",
      "docs": [
        "Per-tier parameters (ARCH §2.3.3 `TierParams`; A, B, C, D), 12 × u32 = 48 B, no padding."
      ],
      "repr": {
        "kind": "c"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "mBps",
            "type": "u32"
          },
          {
            "name": "crOpenBps",
            "type": "u32"
          },
          {
            "name": "crLiqBps",
            "type": "u32"
          },
          {
            "name": "penaltyBps",
            "type": "u32"
          },
          {
            "name": "maxDurationS",
            "type": "u32"
          },
          {
            "name": "impactPosBps",
            "type": "u32"
          },
          {
            "name": "impactMktBps",
            "type": "u32"
          },
          {
            "name": "maxLiqSlipBps",
            "type": "u32"
          },
          {
            "name": "rateBaseBps",
            "type": "u32"
          },
          {
            "name": "rateSlope1Bps",
            "type": "u32"
          },
          {
            "name": "rateSlope2Bps",
            "type": "u32"
          },
          {
            "name": "minRentS",
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "traderSwept",
      "docs": [
        "Trader normalisation or `sweep_trader`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "lamports",
            "type": "u64"
          },
          {
            "name": "tokens",
            "type": "u64"
          },
          {
            "name": "to",
            "docs": [
              "`SWEEP_TO_*`."
            ],
            "type": "u8"
          },
          {
            "name": "wipeBits",
            "docs": [
              "`Market.flags` wipe bits after the sweep."
            ],
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "venueDisabled",
      "docs": [
        "`disable_venue`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "bit",
            "docs": [
              "The `venue_enabled` bit index cleared."
            ],
            "type": "u8"
          },
          {
            "name": "venueEnabled",
            "docs": [
              "`venue_enabled` after the change."
            ],
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "venueExtras",
      "docs": [
        "Bounded venue extras of one venue kind."
      ],
      "serialization": "bytemuck",
      "repr": {
        "kind": "c"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "version",
            "docs": [
              "Layout version ([`crate::constants::VENUE_EXTRAS_VERSION`])."
            ],
            "type": "u16"
          },
          {
            "name": "bump",
            "docs": [
              "PDA bump of `[\"venue_extras\", venue]`."
            ],
            "type": "u8"
          },
          {
            "name": "venue",
            "docs": [
              "The `VenueKind` these sets apply to."
            ],
            "type": "u8"
          },
          {
            "name": "pad0",
            "type": {
              "array": [
                "u8",
                4
              ]
            }
          },
          {
            "name": "sets",
            "docs": [
              "Sell, buy, claim."
            ],
            "type": {
              "array": [
                {
                  "defined": {
                    "name": "ixExtras"
                  }
                },
                3
              ]
            }
          },
          {
            "name": "reserved",
            "type": {
              "array": [
                "u8",
                64
              ]
            }
          }
        ]
      }
    },
    {
      "name": "venueExtrasSet",
      "docs": [
        "`set_venue_extras` (O6; M2)."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "venue",
            "type": "u8"
          },
          {
            "name": "ix",
            "type": "u8"
          },
          {
            "name": "version",
            "type": "u32"
          },
          {
            "name": "keys",
            "type": {
              "array": [
                "pubkey",
                4
              ]
            }
          },
          {
            "name": "stableVersion",
            "docs": [
              "The version of the kind's `stable` set after the write (M2-SEC-2): it changes when the",
              "displaced `current` had stood for `EXTRAS_STABLE_S` or Governance wrote."
            ],
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "venueGuard",
      "docs": [
        "The venue-upgrade latch."
      ],
      "serialization": "bytemuck",
      "repr": {
        "kind": "c"
      },
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "version",
            "docs": [
              "Layout version ([`crate::constants::VENUE_GUARD_VERSION`])."
            ],
            "type": "u16"
          },
          {
            "name": "bump",
            "docs": [
              "PDA bump of `[\"venue_guard\"]`."
            ],
            "type": "u8"
          },
          {
            "name": "pad0",
            "type": "u8"
          },
          {
            "name": "upgraded",
            "docs": [
              "One bit per venue program: upgraded and not yet re-validated."
            ],
            "type": "u32"
          },
          {
            "name": "guardSlot",
            "docs": [
              "Last validated ProgramData deploy slot per venue program."
            ],
            "type": {
              "array": [
                "u64",
                6
              ]
            }
          },
          {
            "name": "flaggedSlot",
            "docs": [
              "The latest deploy slot seen while flagged."
            ],
            "type": {
              "array": [
                "u64",
                6
              ]
            }
          },
          {
            "name": "flaggedAt",
            "docs": [
              "When `flagged_slot` was last recorded (unix seconds)."
            ],
            "type": {
              "array": [
                "i64",
                6
              ]
            }
          },
          {
            "name": "guardLen",
            "docs": [
              "AIR-01: the ProgramData data length at the last revalidation with a hash, per venue from",
              "[`GUARD_ELF_FIRST`]; 0 = no fingerprint."
            ],
            "type": {
              "array": [
                "u32",
                4
              ]
            }
          },
          {
            "name": "guardElf",
            "docs": [
              "AIR-01: the full sha256 of the reviewed trimmed ELF, per",
              "venue from [`GUARD_ELF_FIRST`] (meaningful while `guard_len` is not 0)."
            ],
            "type": {
              "array": [
                {
                  "array": [
                    "u8",
                    32
                  ]
                },
                4
              ]
            }
          }
        ]
      }
    },
    {
      "name": "venueRevalidated",
      "docs": [
        "`revalidate_venue`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "venue",
            "docs": [
              "`VenueGuard` index."
            ],
            "type": "u8"
          },
          {
            "name": "guardSlot",
            "docs": [
              "The previous `guard_slot`."
            ],
            "type": "u64"
          },
          {
            "name": "programdataSlot",
            "docs": [
              "The ProgramData deploy slot now recorded."
            ],
            "type": "u64"
          },
          {
            "name": "flaggedAt",
            "docs": [
              "`flagged_at` of the flag being cleared (0 if the bit was not set)."
            ],
            "type": "i64"
          },
          {
            "name": "expectedSlot",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "venueRewardsClaimed",
      "docs": [
        "`claim_venue_rewards`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "lamports",
            "type": "u64"
          },
          {
            "name": "to",
            "docs": [
              "`SWEEP_TO_*`."
            ],
            "type": "u8"
          },
          {
            "name": "wipeBits",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "venueStateChanged",
      "docs": [
        "A venue state change (graduation, `None →` pump re-detection, …)."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "from",
            "type": "u8"
          },
          {
            "name": "to",
            "type": "u8"
          },
          {
            "name": "pool",
            "type": "pubkey"
          },
          {
            "name": "graduatedAt",
            "type": "i64"
          }
        ]
      }
    },
    {
      "name": "venueUpgradeFlagged",
      "docs": [
        "`flag_venue_upgraded` (the latch set, or `flagged_slot` refreshed while set)."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "venue",
            "docs": [
              "`VenueGuard` index."
            ],
            "type": "u8"
          },
          {
            "name": "guardSlot",
            "type": "u64"
          },
          {
            "name": "programdataSlot",
            "type": "u64"
          },
          {
            "name": "flaggedAt",
            "type": "i64"
          }
        ]
      }
    },
    {
      "name": "walletExposure",
      "docs": [
        "A borrower's open quantity in one market (the per-wallet cap, SPEC §4)."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "wallet",
            "type": "pubkey"
          },
          {
            "name": "qOpen",
            "type": "u64"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "withdraw",
      "docs": [
        "`withdraw`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "ts",
            "type": "i64"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "amount",
            "docs": [
              "Tokens (deposit, withdraw) or lamports (cover)."
            ],
            "type": "u64"
          },
          {
            "name": "shares",
            "docs": [
              "Shares minted or burned."
            ],
            "type": "u128"
          },
          {
            "name": "tAfter",
            "docs": [
              "`T` after the instruction."
            ],
            "type": "u64"
          },
          {
            "name": "sAfter",
            "docs": [
              "`S` after the instruction."
            ],
            "type": "u128"
          },
          {
            "name": "solPaid",
            "docs": [
              "SOL paid to the lender."
            ],
            "type": "u64"
          },
          {
            "name": "potDraw",
            "docs": [
              "Of which drawn from the pot."
            ],
            "type": "u64"
          },
          {
            "name": "lock",
            "docs": [
              "The lender's lock after the instruction."
            ],
            "type": "u128"
          },
          {
            "name": "lockUntil",
            "type": "i64"
          },
          {
            "name": "epoch",
            "docs": [
              "The lender's share epoch after the instruction."
            ],
            "type": "u32"
          }
        ]
      }
    }
  ]
};
